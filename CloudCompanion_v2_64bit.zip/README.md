# Cloud Companion 2.0 (64-bit)

A rebuilt, 64-bit version of the Yontoys **Cloud Companion** app (v1.9.1) for modern Android phones.
Same screens, images, sounds, languages and car protocol as the original.

## Build (GitHub Actions)
1. Put the contents of this ZIP at the **root** of a GitHub repository
   (`settings.gradle.kts` must be at the top level, next to `app/` and `.github/`).
2. Push. The workflow `.github/workflows/build.yml` downloads the official Nabto 4 SDK and builds the APK.
3. Open the run, download the `CloudCompanion-APK` artifact and install it.

## What changed vs. the original
| Original (2016, 32-bit only) | Now |
|---|---|
| libnabto_client_api_jni.so (armeabi-v7a) | Official Nabto 4 client SDK 1.7.x, arm64-v8a + armeabi-v7a |
| libdemo.sdk.so RTSP player | libVLC 3.5.1 (64-bit), auto fallback UDP -> TCP |
| SnappyDB (native) | SharedPreferences (same keys) |
| Apache HttpClient | HttpURLConnection |
| Android 2.3 target | Android 14 target, runtime permissions, cleartext allowed |
| Traffic could leave via mobile data | Process is bound to Wi-Fi when Wi-Fi is up |

## Protocol notes (from the original app)
* Control: TCP to car port 80 through a Nabto tunnel, 11-byte frame every 200 ms:
  `01 55 92 09 mode a b c d e xor` (mode 1 drive, mode 3 wheel calibration).
* Status: 9-byte frame `01 55 92 07 01 battery charging ..`.
* Video: `rtsp://admin:<pwd>@<host>:554/cam1/h264` (720p) or `/cam1/h264-1` (VGA).
* Talk: G.711 u-law 8 kHz, `POST /audio.input`.
* LAN discovery: UDP broadcast to port 5570, device id from byte 19.
* Car hotspot: 192.168.100.1, HTTP `param.cgi` / `server.command` with Basic auth (admin).
