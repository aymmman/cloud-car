plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

// Official Nabto 4 (legacy) client SDK, checked out by the CI workflow into ../nabto-sdk
val nabtoSdk = rootProject.file("nabto-sdk/src/main")

android {
    namespace = "com.ayman.cloudcar"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.ayman.cloudcompanion"
        minSdk = 24
        targetSdk = 34
        versionCode = 200
        versionName = "2.0.0"
        ndk {
            abiFilters += listOf("arm64-v8a", "armeabi-v7a")
        }
    }

    sourceSets {
        getByName("main") {
            java.srcDirs("src/main/java", File(nabtoSdk, "java"), File(nabtoSdk, "jniJava"))
            jniLibs.srcDirs(File(nabtoSdk, "jniLibs"))
        }
    }

    buildTypes {
        getByName("debug") {
            isMinifyEnabled = false
        }
        getByName("release") {
            isMinifyEnabled = false
            signingConfig = signingConfigs.getByName("debug")
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions {
        jvmTarget = "17"
    }

    packaging {
        jniLibs {
            useLegacyPackaging = true
            pickFirsts += listOf("**/libc++_shared.so")
        }
    }

    lint {
        abortOnError = false
        checkReleaseBuilds = false
    }
}

dependencies {
    implementation("org.videolan.android:libvlc-all:3.5.1")
}
