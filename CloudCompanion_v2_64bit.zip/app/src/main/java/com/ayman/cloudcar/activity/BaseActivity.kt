package com.ayman.cloudcar.activity

import android.app.Activity
import android.app.ProgressDialog
import android.content.Context
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.Window
import android.view.WindowManager
import android.widget.Toast
import com.ayman.cloudcar.core.App
import com.ayman.cloudcar.core.LocaleHelper
import java.lang.ref.WeakReference

/** Common base: language, no title bar, simple helpers, and a registry to close wizard screens. */
open class BaseActivity : Activity() {

    protected val main = Handler(Looper.getMainLooper())
    protected val app: App get() = application as App
    private var progress: ProgressDialog? = null

    override fun attachBaseContext(newBase: Context) {
        super.attachBaseContext(LocaleHelper.wrap(newBase))
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        requestWindowFeature(Window.FEATURE_NO_TITLE)
        super.onCreate(savedInstanceState)
        synchronized(open) { open.add(WeakReference(this)) }
    }

    override fun onDestroy() {
        dismissProgress()
        synchronized(open) { open.removeAll { it.get() == null || it.get() === this } }
        super.onDestroy()
    }

    fun toast(msg: String) = Toast.makeText(applicationContext, msg, Toast.LENGTH_SHORT).show()

    @Suppress("DEPRECATION")
    fun showProgress(msg: String) {
        dismissProgress()
        if (isFinishing) return
        progress = ProgressDialog.show(this, "", msg, true)
    }

    @Suppress("DEPRECATION")
    fun setProgressMessage(msg: String) { progress?.setMessage(msg) }

    fun dismissProgress() {
        try { progress?.takeIf { it.isShowing }?.dismiss() } catch (_: Exception) {}
        progress = null
    }

    fun hideKeyboard() {
        window.setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_HIDDEN)
    }

    /** Runs [work] on a background thread and [done] on the UI thread (if still alive). */
    fun <T> async(work: () -> T, done: (T) -> Unit) {
        Thread {
            val r = work()
            runOnUiThread { if (!isFinishing && !isDestroyed) done(r) }
        }.start()
    }

    companion object {
        private val open = mutableListOf<WeakReference<Activity>>()

        /** Finishes every open screen of the given types (the original used static self() refs). */
        fun finishAll(vararg types: Class<out Activity>) {
            val list = synchronized(open) { open.mapNotNull { it.get() } }
            list.filter { a -> types.any { it.isInstance(a) } }.forEach { it.finish() }
        }

        val wizardScreens: Array<Class<out Activity>> = arrayOf(
            AddCarActivity::class.java, AddLocalCarActivity::class.java, AddLocalCar2Activity::class.java,
            AddRemoteCarActivity::class.java, ConnectCarActivity::class.java, ConfigCarActivity::class.java,
            ProcessingCarActivity::class.java, ProcessCarSuccessActivity::class.java
        )
    }
}
