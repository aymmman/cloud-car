package com.ayman.cloudcar.activity

import android.Manifest
import android.annotation.SuppressLint
import android.content.Intent
import android.content.pm.ActivityInfo
import android.content.pm.PackageManager
import android.content.res.Configuration
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.media.AudioManager
import android.media.MediaPlayer
import android.os.Bundle
import android.os.Environment
import android.view.KeyEvent
import android.view.MotionEvent
import android.view.Surface
import android.view.View
import android.view.WindowManager
import android.widget.ImageView
import android.widget.ProgressBar
import android.widget.TextView
import com.ayman.cloudcar.R
import com.ayman.cloudcar.core.CarEntity
import com.ayman.cloudcar.core.ControlLink
import com.ayman.cloudcar.core.MediaSaver
import com.ayman.cloudcar.core.NabtoManager
import com.ayman.cloudcar.core.TalkBack
import com.ayman.cloudcar.core.VideoPlayer
import com.ayman.cloudcar.ui.ActionButtonView
import com.ayman.cloudcar.ui.BatteryView
import com.ayman.cloudcar.ui.DirectionControlView
import com.ayman.cloudcar.ui.HeaderButtonView
import com.ayman.cloudcar.ui.JoystickView
import com.ayman.cloudcar.ui.RecordView
import org.videolan.libvlc.util.VLCVideoLayout
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.TimeZone

/** The driving screen: live video, joystick / two-thumb pad, gravity, camera tilt, light, photo, video, talk. */
class CarActivity : BaseActivity(), SensorEventListener {

    private lateinit var car: CarEntity
    private lateinit var control: ControlLink
    private val player: VideoPlayer get() = app.player
    private val talk = TalkBack()
    private lateinit var audio: AudioManager
    private lateinit var sensors: SensorManager

    // views (some exist only in portrait or only in landscape)
    private var lockBtn: ActionButtonView? = null
    private var lightBtn: ActionButtonView? = null
    private var gravityBtn: ActionButtonView? = null
    private var photoBtn: ActionButtonView? = null
    private var shootBtn: ActionButtonView? = null
    private var camUpBtn: ActionButtonView? = null
    private var camDownBtn: ActionButtonView? = null
    private var settingBtn: ActionButtonView? = null
    private var voiceBtn: ActionButtonView? = null
    private var changeCarBtn: ActionButtonView? = null
    private var headerChangeCarBtn: HeaderButtonView? = null
    private var joystick: JoystickView? = null
    private var dirView: DirectionControlView? = null
    private var battery: BatteryView? = null
    private var audioIcon: ImageView? = null
    private var pipeIcon: ImageView? = null
    private var recordView: RecordView? = null
    private var voiceText: TextView? = null
    private var progressBar: ProgressBar? = null

    private var videoReady = false
    private var batteryValue = 100f
    private var charging = false
    private var light = false
    private var gravity = false
    private var lastVolume = 0
    private var recordStart = 0L
    private var voiceStart = 0L
    private var closing = false
    private var wheelCallback: ((Boolean) -> Unit)? = null

    private var shutterSound: MediaPlayer? = null
    private var beginSound: MediaPlayer? = null
    private var endSound: MediaPlayer? = null

    private val remote get() = car.type == CarEntity.TYPE_REMOTE
    /** HTTP / talk-back endpoint of the car (direct when local, through the tunnel when remote). */
    private val httpHost get() = if (remote) "127.0.0.1" else car.ip
    private val httpPort get() = if (remote) car.controlPort else 80

    private val ticker = object : Runnable {
        override fun run() {
            val now = System.currentTimeMillis()
            if (player.isRecording) recordView?.text = format(now - recordStart, "HH:mm:ss")
            if (voiceText?.visibility == View.VISIBLE) voiceText?.text = format(now - voiceStart, "mm:ss")
            main.postDelayed(this, 500)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        current = this
        setContentView(R.layout.activity_car)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        @Suppress("DEPRECATION")
        car = intent.getSerializableExtra("car") as CarEntity

        audio = getSystemService(AUDIO_SERVICE) as AudioManager
        volumeControlStream = AudioManager.STREAM_MUSIC
        shutterSound = MediaPlayer.create(this, R.raw.shutter)
        beginSound = MediaPlayer.create(this, R.raw.begin_record)
        endSound = MediaPlayer.create(this, R.raw.end_record)

        control = ControlLink(car.controlPort) {
            val r = app.nabto.openTunnel(NabtoManager.randomPort(), car.id, 80)
            if (r.ok) r.localPort.also { car.controlPort = it } else null
        }
        control.listener = object : ControlLink.Listener {
            override fun onBattery(percent: Int, charging: Boolean) {
                batteryValue = percent.toFloat(); this@CarActivity.charging = charging
                battery?.setCharging(charging); battery?.setAmount(batteryValue)
            }
            override fun onWheelSpeedResult(success: Boolean) {
                wheelCallback?.invoke(success); wheelCallback = null
            }
        }
        control.start()

        sensors = getSystemService(SENSOR_SERVICE) as SensorManager
        sensors.getDefaultSensor(Sensor.TYPE_ACCELEROMETER)?.let {
            sensors.registerListener(this, it, SensorManager.SENSOR_DELAY_GAME)
        }

        player.onVideoReceived = { onVideo() }
        player.onError = { toast(getString(R.string.connect_car_err) + ": video]") }
        initView()
        startVideo()
        main.post(ticker)
    }

    private fun startVideo() {
        videoReady = false
        player.play(httpHost, if (remote) car.playPort else 554, car.pipe, remote, "admin", car.password)
    }

    override fun onConfigurationChanged(newConfig: Configuration) {
        super.onConfigurationChanged(newConfig)
        setContentView(R.layout.activity_car)
        initView()
    }

    @SuppressLint("ClickableViewAccessibility")
    private fun initView() {
        lockBtn = findViewById(R.id.lockActionButton)
        lightBtn = findViewById(R.id.lightActionButton)
        gravityBtn = findViewById(R.id.gravityActionButton)
        photoBtn = findViewById(R.id.cameraPhotographActionButton)
        shootBtn = findViewById(R.id.cameraShootingActionButton)
        camUpBtn = findViewById(R.id.cameraUpActionButton)
        camDownBtn = findViewById(R.id.cameraDownActionButton)
        settingBtn = findViewById(R.id.settingActionButton)
        voiceBtn = findViewById(R.id.voiceButton)
        changeCarBtn = findViewById(R.id.changeCarActionButton)
        headerChangeCarBtn = findViewById(R.id.headerChangeCarButton)
        joystick = findViewById(R.id.joystickView)
        dirView = findViewById(R.id.directionControlView)
        battery = findViewById(R.id.batteryView)
        audioIcon = findViewById(R.id.iv_audio)
        pipeIcon = findViewById(R.id.iV_changePipe)
        recordView = findViewById(R.id.recordView)
        voiceText = findViewById(R.id.voiceTextView)
        progressBar = findViewById(R.id.videoProgressBar)

        player.attach(findViewById<VLCVideoLayout>(R.id.displayView))

        findViewById<TextView>(R.id.headerTextView)?.text = CarEntity.getCarNameFromId(car.id) + " (" +
                getString(if (remote) R.string.remote else R.string.local) + ")"
        pipeIcon?.setImageResource(
            if (car.pipe == CarEntity.PIPE_PRIMARY) R.drawable.bg_changepipe_720p else R.drawable.bg_changepipe_vga
        )
        battery?.setAmount(batteryValue); battery?.setCharging(charging)
        lightBtn?.isSelected = light
        gravityBtn?.isSelected = gravity
        lockBtn?.isSelected = gravity
        recordView?.visibility = if (player.isRecording) View.VISIBLE else View.GONE
        updateVolume()
        setControlsEnabled(videoReady)
        progressBar?.visibility = if (videoReady) View.INVISIBLE else View.VISIBLE
        if (!videoReady) lockOrientation(true)

        settingBtn?.setOnClickListener {
            startActivityForResult(Intent(this, CarSettingActivity::class.java)
                .putExtra("car", car).putExtra("http_host", "$httpHost:$httpPort"), 1)
        }
        audioIcon?.setOnClickListener {
            val v = audio.getStreamVolume(AudioManager.STREAM_MUSIC)
            if (v == 0) audio.setStreamVolume(AudioManager.STREAM_MUSIC, if (lastVolume == 0) 9 else lastVolume, 0)
            else { lastVolume = v; audio.setStreamVolume(AudioManager.STREAM_MUSIC, 0, 0) }
            updateVolume()
        }
        pipeIcon?.setOnClickListener { changePipe() }
        camUpBtn?.setOnTouchListener { _, e -> tilt(e, 1); false }
        camDownBtn?.setOnTouchListener { _, e -> tilt(e, 2); false }
        lockBtn?.setOnClickListener {
            val sel = !(lockBtn?.isSelected ?: false)
            lockBtn?.isSelected = sel
            if (!sel) joystick?.useSensor = false
            lockOrientation(sel)
        }
        lightBtn?.setOnClickListener {
            light = !light
            lightBtn?.isSelected = light
            control.light = if (light) 1 else 0
        }
        gravityBtn?.setOnClickListener {
            gravity = !gravity
            gravityBtn?.isSelected = gravity
            joystick?.isEnabled = !gravity
            dirView?.isEnabled = !gravity
            lockBtn?.isSelected = gravity
            lockOrientation(gravity)
            if (!gravity) control.direction = 0
        }
        joystick?.listener = JoystickView.OnJoystickMoveListener { _, _, d -> if (!gravity) control.direction = d }
        dirView?.listener = DirectionControlView.OnDirectionUpdateListener { d -> if (!gravity) control.direction = d }
        headerChangeCarBtn?.setOnClickListener { headerChangeCarBtn?.isEnabled = false; close() }
        changeCarBtn?.setOnClickListener { changeCarBtn?.isEnabled = false; close() }
        photoBtn?.setOnClickListener { takePhoto() }
        shootBtn?.setOnClickListener { toggleRecord() }
        voiceBtn?.setOnTouchListener { _, e -> voice(e); true }
    }

    private fun tilt(e: MotionEvent, value: Int) {
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> control.cameraRoll = value
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> control.cameraRoll = 0
        }
    }

    private fun onVideo() {
        videoReady = true
        progressBar?.visibility = View.INVISIBLE
        setControlsEnabled(true)
        if (!gravity && lockBtn?.isSelected != true) lockOrientation(false)
    }

    private fun setControlsEnabled(on: Boolean) {
        listOf(lockBtn, lightBtn, gravityBtn, photoBtn, shootBtn, camUpBtn, camDownBtn, settingBtn, voiceBtn)
            .forEach { it?.isEnabled = on }
        joystick?.isEnabled = on && !gravity
        dirView?.isEnabled = on && !gravity
    }

    private fun lockOrientation(lock: Boolean) {
        requestedOrientation = if (lock) ActivityInfo.SCREEN_ORIENTATION_LOCKED else ActivityInfo.SCREEN_ORIENTATION_SENSOR
    }

    private fun changePipe() {
        car.pipe = if (car.pipe == CarEntity.PIPE_PRIMARY) CarEntity.PIPE_SECONDARY else CarEntity.PIPE_PRIMARY
        pipeIcon?.setImageResource(
            if (car.pipe == CarEntity.PIPE_PRIMARY) R.drawable.bg_changepipe_720p else R.drawable.bg_changepipe_vga
        )
        progressBar?.visibility = View.VISIBLE
        setControlsEnabled(false)
        lockOrientation(true)
        if (player.isRecording) stopRecording()
        startVideo()
    }

    private fun takePhoto() {
        photoBtn?.isEnabled = false
        shutterSound?.start()
        val bmp = player.takePhoto()
        if (bmp == null) { photoBtn?.isEnabled = true; return }
        async({ MediaSaver.savePhoto(this, bmp) }) { path ->
            photoBtn?.isEnabled = true
            if (path != null) toast(getString(R.string.photo_save_to) + path)
        }
    }

    private fun recordDir() = File(getExternalFilesDir(Environment.DIRECTORY_MOVIES) ?: filesDir, "recording")

    private fun toggleRecord() {
        if (player.isRecording) { stopRecording(); return }
        beginSound?.start()
        if (player.beginRecord(recordDir())) {
            recordStart = System.currentTimeMillis()
            recordView?.text = "00:00:00"
            recordView?.visibility = View.VISIBLE
        } else {
            toast(getString(R.string.video_save_to) + " -")
        }
    }

    private fun stopRecording() {
        endSound?.start()
        player.stopRecord()
        recordView?.visibility = View.INVISIBLE
        val dir = recordDir()
        main.postDelayed({
            Thread {
                val path = MediaSaver.publishVideos(applicationContext, dir)
                if (path != null) runOnUiThread { toast(getString(R.string.video_save_to) + path) }
            }.start()
        }, 1500)
    }

    private fun voice(e: MotionEvent) {
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
                    requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), 2)
                    return
                }
                if (talk.begin(httpHost, httpPort)) {
                    voiceStart = System.currentTimeMillis()
                    voiceText?.text = "00:00"
                    voiceText?.visibility = View.VISIBLE
                }
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                talk.stop()
                voiceText?.visibility = View.GONE
            }
        }
    }

    private fun updateVolume() {
        val v = audio.getStreamVolume(AudioManager.STREAM_MUSIC)
        audioIcon?.setImageResource(
            when {
                v == 0 -> R.drawable.voice_0
                v < 5 -> R.drawable.voice_1
                v < 10 -> R.drawable.voice_2
                else -> R.drawable.voice_3
            }
        )
    }

    override fun onKeyDown(keyCode: Int, event: KeyEvent?): Boolean {
        when (keyCode) {
            KeyEvent.KEYCODE_VOLUME_UP -> {
                audio.adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_RAISE, AudioManager.FLAG_SHOW_UI)
                updateVolume(); return true
            }
            KeyEvent.KEYCODE_VOLUME_DOWN -> {
                audio.adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_LOWER, AudioManager.FLAG_SHOW_UI)
                updateVolume(); return true
            }
        }
        return super.onKeyDown(keyCode, event)
    }

    /** Called from the settings screen (wheel calibration). */
    fun changeWheelSpeed(left: Int, right: Int, done: (Boolean) -> Unit) {
        wheelCallback = done
        control.changeWheelSpeed(left, right)
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (resultCode == CarSettingActivity.RESULT_PASSWORD) {
            data?.getStringExtra("password")?.let { car.password = it }
        }
    }

    // ---------- gravity (accelerometer) driving, same thresholds as the original ----------
    override fun onSensorChanged(event: SensorEvent) {
        if (!gravity) return
        val gx = event.values[0]; val gy = event.values[1]
        var left = false; var right = false; var front = false; var bottom = false
        when (screenOrientation()) {
            ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE -> {
                right = gy > 2; left = gy < -2; bottom = gx > 2; front = gx < -2
            }
            ActivityInfo.SCREEN_ORIENTATION_PORTRAIT -> {
                bottom = gy > 2; front = gy < -2; left = gx > 2; right = gx < -2
            }
            ActivityInfo.SCREEN_ORIENTATION_REVERSE_LANDSCAPE -> {
                left = gy > 2; right = gy < -2; front = gx > 2; bottom = gx < -2
            }
            else -> {
                front = gy > 2; bottom = gy < -2; right = gx > 2; left = gx < -2
            }
        }
        control.direction = when {
            left -> if (front) 4 else if (bottom) 6 else 5
            right -> if (front) 2 else if (bottom) 8 else 1
            front -> 3
            bottom -> 7
            else -> 0
        }
    }

    override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) {}

    @Suppress("DEPRECATION")
    private fun screenOrientation(): Int = when (windowManager.defaultDisplay.rotation) {
        Surface.ROTATION_0 -> ActivityInfo.SCREEN_ORIENTATION_PORTRAIT
        Surface.ROTATION_90 -> ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE
        Surface.ROTATION_180 -> ActivityInfo.SCREEN_ORIENTATION_REVERSE_PORTRAIT
        else -> ActivityInfo.SCREEN_ORIENTATION_REVERSE_LANDSCAPE
    }

    // ---------- leaving ----------
    private fun close() {
        if (closing) return
        closing = true
        if (player.isRecording) stopRecording()
        shutdown()
        setResult(RESULT_OK)
        finish()
    }

    private fun shutdown() {
        talk.stop()
        control.stop()
        player.onVideoReceived = null
        player.onError = null
        player.stop()
        player.detach()
        app.nabto.closeTunnels()
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() = close()

    override fun onDestroy() {
        main.removeCallbacks(ticker)
        sensors.unregisterListener(this)
        if (!closing) { closing = true; shutdown() }
        listOf(shutterSound, beginSound, endSound).forEach { try { it?.release() } catch (_: Exception) {} }
        if (current === this) current = null
        super.onDestroy()
    }

    private fun format(ms: Long, pattern: String): String =
        SimpleDateFormat(pattern, Locale.US).apply { timeZone = TimeZone.getTimeZone("UTC") }.format(Date(ms))

    companion object {
        var current: CarActivity? = null
            private set
    }
}
