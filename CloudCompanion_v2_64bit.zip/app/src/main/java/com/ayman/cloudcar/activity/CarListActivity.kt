package com.ayman.cloudcar.activity

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.view.View
import android.view.animation.AnimationUtils
import android.widget.ImageButton
import android.widget.RelativeLayout
import android.widget.TextView
import com.ayman.cloudcar.R
import com.ayman.cloudcar.core.CarEntity
import com.ayman.cloudcar.core.CarStore
import com.ayman.cloudcar.core.LocaleHelper
import com.ayman.cloudcar.core.NetUtil
import com.ayman.cloudcar.core.Scanner
import com.ayman.cloudcar.ui.CarListView
import com.ayman.cloudcar.ui.HeaderButtonView

class CarListActivity : BaseActivity() {

    private lateinit var refresh: HeaderButtonView
    private lateinit var header: TextView
    private lateinit var listView: CarListView
    private lateinit var tipView: View
    private var loading = false

    private val flags by lazy {
        mapOf(
            "zh" to Triple(R.id.imageBtn_changeLanguage_ZH_rCN, R.drawable.china, R.drawable.china_w),
            "hk" to Triple(R.id.imageBtn_changeLanguage_ZH_rHK, R.drawable.china_hk, R.drawable.china_hk_w),
            "en" to Triple(R.id.imageBtn_changeLanguage_EN, R.drawable.america, R.drawable.america_w),
            "es" to Triple(R.id.imageBtn_changeLanguage_ES, R.drawable.spain, R.drawable.spain_w),
            "ko" to Triple(R.id.imageBtn_changeLanguage_KO, R.drawable.korea, R.drawable.korea_w),
            "ru" to Triple(R.id.imageBtn_changeLanguage_RU, R.drawable.russia, R.drawable.russia_w)
        )
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_car_list)
        refresh = findViewById(R.id.refreshButton)
        header = findViewById(R.id.headerTextView)
        listView = findViewById(R.id.carListView)
        tipView = findViewById(R.id.tipView)

        // language bar: full width, 1/8 of the width high, at the bottom (as in the original)
        val bar = findViewById<RelativeLayout>(R.id.relalayout_logoAndChangeLanguageBtn)
        val w = resources.displayMetrics.widthPixels
        (bar.layoutParams as? RelativeLayout.LayoutParams)?.let {
            it.width = w; it.height = w / 8
            it.addRule(RelativeLayout.ALIGN_PARENT_BOTTOM)
            bar.layoutParams = it
        }
        val cur = LocaleHelper.current(this)
        flags.forEach { (lang, f) ->
            val b = findViewById<ImageButton>(f.first)
            b.setBackgroundResource(if (lang == cur) f.second else f.third)
            b.setOnClickListener {
                if (lang != LocaleHelper.current(this)) {
                    LocaleHelper.set(this, lang)
                    recreate()
                }
            }
        }
        header.setText(R.string.choose_car)

        findViewById<HeaderButtonView>(R.id.helpButton).setOnClickListener {
            startActivity(Intent(this, HelpActivity::class.java))
        }
        refresh.setOnClickListener {
            refresh.startAnimation(AnimationUtils.loadAnimation(this, R.anim.rotate))
            loadCars()
        }
        askPermissions()
    }

    private fun askPermissions() {
        val need = mutableListOf<String>()
        if (checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED)
            need += Manifest.permission.ACCESS_FINE_LOCATION
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED)
            need += Manifest.permission.RECORD_AUDIO
        if (Build.VERSION.SDK_INT <= 28 &&
            checkSelfPermission(Manifest.permission.WRITE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED)
            need += Manifest.permission.WRITE_EXTERNAL_STORAGE
        if (need.isNotEmpty()) requestPermissions(need.toTypedArray(), 1)
    }

    override fun onResume() {
        super.onResume()
        loadCars()
    }

    fun loadCars() {
        if (loading) return
        loading = true
        showProgress(getString(R.string.get_car_list))
        refresh.isEnabled = false
        async({ Scanner.scan(this) }) { scanned -> showCars(scanned) }
    }

    private fun showCars(scanned: Map<String, String>) {
        loading = false
        val found = LinkedHashMap<String, CarEntity>()
        scanned.forEach { (ip, id) ->
            found[id] = CarEntity(id, ip, CarEntity.getCarNameFromId(id), false, ip == CarEntity.CAR_AP_IP)
        }
        val data = ArrayList<CarEntity>()
        for (car in CarStore(this).savedCars()) {
            car.remote = true
            car.ip = "127.0.0.1"
            found.remove(car.id)?.let { s ->
                car.remote = false
                car.ip = s.ip
                car.direct = s.direct
            }
            data.add(car)
        }
        data.addAll(0, found.values)
        val gateway = NetUtil.gatewayAddress(this)
        val connectedToCar = data.any { it.ip == gateway }
        tipView.visibility = if (data.isEmpty()) View.VISIBLE else View.GONE
        if (!connectedToCar) data.add(CarEntity(name = getString(R.string.add_car)))
        listView.setData(data)
        refresh.isEnabled = true
        refresh.clearAnimation()
        header.visibility = View.VISIBLE
        dismissProgress()
    }
}
