package com.ayman.cloudcar.activity

import android.content.Intent
import android.graphics.Typeface
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.widget.Button
import android.widget.EditText
import android.widget.SeekBar
import com.ayman.cloudcar.R
import com.ayman.cloudcar.core.CarEntity
import com.ayman.cloudcar.core.CarHttp
import com.ayman.cloudcar.core.CarStore
import com.ayman.cloudcar.ui.HeaderButtonView

/** Change the car password and calibrate the left/right wheel speed (0-100). */
class CarSettingActivity : BaseActivity() {

    private lateinit var car: CarEntity
    private var syncing = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_car_setting)
        @Suppress("DEPRECATION")
        car = intent.getSerializableExtra("car") as CarEntity
        val httpHost = intent.getStringExtra("http_host") ?: "${car.ip}:80"

        findViewById<HeaderButtonView>(R.id.headerCloseButton).setOnClickListener {
            setResult(RESULT_OK); finish()
        }

        val leftBar = findViewById<SeekBar>(R.id.leftWheelSeekBar)
        val rightBar = findViewById<SeekBar>(R.id.rightWheelSeekBar)
        val leftEdit = findViewById<EditText>(R.id.leftWheelEditText)
        val rightEdit = findViewById<EditText>(R.id.rightWheelEditText)
        leftBar.max = 100; rightBar.max = 100
        bind(leftBar, leftEdit)
        bind(rightBar, rightEdit)

        findViewById<Button>(R.id.modifySpeedButton).setOnClickListener {
            val carScreen = CarActivity.current ?: return@setOnClickListener
            showProgress(getString(R.string.change_car_speed_progress))
            carScreen.changeWheelSpeed(leftBar.progress, rightBar.progress) { ok ->
                dismissProgress()
                toast(getString(if (ok) R.string.change_car_speed_success else R.string.change_car_speed_fail))
            }
        }

        val pwdEdit = findViewById<EditText>(R.id.pwdEditText)
        pwdEdit.typeface = Typeface.DEFAULT
        findViewById<Button>(R.id.modifyButton).setOnClickListener {
            val newPwd = pwdEdit.text.toString()
            if (newPwd.isEmpty()) { toast(getString(R.string.car_pwd_err)); return@setOnClickListener }
            showProgress(getString(R.string.change_car_pwd_progress))
            async({ CarHttp(httpHost, car.password).updatePassword(newPwd).ok }) { ok ->
                dismissProgress()
                toast(getString(if (ok) R.string.change_car_pwd_success else R.string.change_car_pwd_fail))
                if (ok) {
                    CarStore(this).setPassword(car.id, newPwd)
                    setResult(RESULT_PASSWORD, Intent().putExtra("password", newPwd))
                    finish()
                }
            }
        }
    }

    private fun bind(bar: SeekBar, edit: EditText) {
        bar.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar, p: Int, fromUser: Boolean) {
                if (syncing) return
                syncing = true
                edit.setText(p.toString()); edit.setSelection(edit.text.length)
                syncing = false
            }
            override fun onStartTrackingTouch(s: SeekBar) {}
            override fun onStopTrackingTouch(s: SeekBar) {}
        })
        edit.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            override fun onTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            override fun afterTextChanged(e: Editable?) {
                if (syncing) return
                val v = e?.toString()?.trim()?.toIntOrNull() ?: return
                val clamped = v.coerceIn(0, 100)
                syncing = true
                if (clamped != v) { edit.setText(clamped.toString()); edit.setSelection(edit.text.length) }
                bar.progress = clamped
                syncing = false
            }
        })
    }

    companion object { const val RESULT_PASSWORD = 13 }
}
