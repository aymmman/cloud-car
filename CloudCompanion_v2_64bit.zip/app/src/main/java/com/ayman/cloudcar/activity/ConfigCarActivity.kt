package com.ayman.cloudcar.activity

import android.app.Dialog
import android.content.Intent
import android.graphics.Typeface
import android.os.Bundle
import android.text.InputType
import android.view.View
import android.view.ViewGroup
import android.widget.BaseAdapter
import android.widget.Button
import android.widget.EditText
import android.widget.ImageView
import android.widget.ListView
import android.widget.TextView
import com.ayman.cloudcar.R
import com.ayman.cloudcar.core.CarEntity
import com.ayman.cloudcar.core.CarHttp
import com.ayman.cloudcar.ui.EditTextWithPicture
import com.ayman.cloudcar.ui.HeaderButtonView

/** Phone is on the car's hotspot: choose the home Wi-Fi the car should join. */
class ConfigCarActivity : BaseActivity() {

    private lateinit var ssidEdit: EditText
    private lateinit var pwd: EditTextWithPicture
    private var version = ""
    private var showPwd = false
    private var timedOut = false
    private val timeout = Runnable {
        timedOut = true
        dismissProgress()
        toast(getString(R.string.apscan_timeout))
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_config_car)
        hideKeyboard()
        version = intent.getStringExtra("version") ?: ""
        ssidEdit = findViewById(R.id.ssidEditText)
        pwd = findViewById(R.id.pwdEditText)
        pwd.text.typeface = Typeface.DEFAULT
        pwd.text.inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
        pwd.text.hint = getString(R.string.wifi_pwd)
        pwd.imageView.setOnClickListener {
            showPwd = !showPwd
            pwd.text.inputType = if (showPwd) InputType.TYPE_CLASS_TEXT
            else InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
            pwd.text.setSelection(pwd.text.length())
        }
        findViewById<TextView>(R.id.apscanStatus).visibility = View.INVISIBLE
        val scanBtn = findViewById<ImageView>(R.id.configwifi)
        scanBtn.visibility = if (version.isEmpty()) View.INVISIBLE else View.VISIBLE
        scanBtn.setOnClickListener { scanWifi() }
        findViewById<HeaderButtonView>(R.id.headerCloseButton).setOnClickListener { finish() }
        findViewById<Button>(R.id.nextButton).setOnClickListener {
            val ssid = ssidEdit.text.toString()
            val p = pwd.content
            val msg = when {
                ssid.isEmpty() -> { ssidEdit.requestFocus(); getString(R.string.route_ssid_err) }
                !CarEntity.checkRouteName(ssid) || !CarEntity.checkRoutePassword(p) -> getString(R.string.ssid_error)
                else -> null
            }
            if (msg != null) { toast(msg); return@setOnClickListener }
            startActivity(Intent(this, ProcessingCarActivity::class.java)
                .putExtra("type", 2).putExtra("ssid", ssid).putExtra("password", p).putExtra("version", version))
        }
    }

    private fun scanWifi() {
        timedOut = false
        showProgress(getString(R.string.get_network_list))
        main.postDelayed(timeout, 15_000)
        async({ CarHttp("${CarEntity.CAR_AP_IP}:80", "admin").getWifiList() }) { r ->
            if (timedOut) return@async
            main.removeCallbacks(timeout)
            dismissProgress()
            if (!r.ok) return@async
            val ssids = CarHttp.parseSsids(r.body)
            if (ssids.isNotEmpty()) showList(ssids)
        }
    }

    private fun showList(ssids: List<String>) {
        val dialog = Dialog(this, R.style.myDialogTheme)
        val v = layoutInflater.inflate(R.layout.apscan_admin, null)
        v.findViewById<TextView>(R.id.apscan_admin_head).setText(R.string.apscan_admin_head)
        val list = v.findViewById<ListView>(R.id.apscan_admin_list)
        list.adapter = object : BaseAdapter() {
            override fun getCount() = ssids.size
            override fun getItem(position: Int) = ssids[position]
            override fun getItemId(position: Int) = position.toLong()
            override fun getView(position: Int, convertView: View?, parent: ViewGroup?): View {
                val item = convertView ?: layoutInflater.inflate(R.layout.apscan_list_item, parent, false)
                item.findViewById<TextView>(R.id.Wifi_name).text = ssids[position]
                return item
            }
        }
        list.setOnItemClickListener { _, _, position, _ ->
            ssidEdit.setText(ssids[position])
            dialog.dismiss()
        }
        dialog.setContentView(v)
        dialog.show()
    }

    override fun onDestroy() {
        main.removeCallbacks(timeout)
        super.onDestroy()
    }
}
