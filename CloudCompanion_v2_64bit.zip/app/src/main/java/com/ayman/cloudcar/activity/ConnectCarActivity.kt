package com.ayman.cloudcar.activity

import android.content.Intent
import android.graphics.Typeface
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.RelativeLayout
import android.widget.TextView
import com.ayman.cloudcar.R
import com.ayman.cloudcar.core.CarEntity
import com.ayman.cloudcar.core.CarHttp
import com.ayman.cloudcar.core.CarStore
import com.ayman.cloudcar.core.NabtoManager
import com.ayman.cloudcar.core.NetUtil
import com.ayman.cloudcar.ui.HeaderButtonView

/**
 * Same flow as the original:
 *  remote: tunnel 554 (video) + tunnel 80 (control), then password check over the tunnel.
 *  local : tunnel 80 (control), password check directly on <car ip>:80, video direct RTSP/UDP.
 */
class ConnectCarActivity : BaseActivity() {

    private lateinit var car: CarEntity
    private lateinit var pwdEdit: EditText
    private val store by lazy { CarStore(this) }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_connect_car)
        @Suppress("DEPRECATION")
        car = intent.getSerializableExtra("car") as CarEntity
        pwdEdit = findViewById(R.id.pwdEditText)
        pwdEdit.typeface = Typeface.DEFAULT
        store.getPassword(car.id)?.let { pwdEdit.setText(it) }

        findViewById<TextView>(R.id.headerTextView).text = getString(R.string.connect_to_car) + " (" +
                (if (car.remote == true) getString(R.string.remote) else getString(R.string.local)) + ")"
        findViewById<HeaderButtonView>(R.id.headerCloseButton).setOnClickListener { finish() }

        // "Configure car Wi-Fi" is only offered when the phone is connected to the car's own hotspot
        val configBtn = findViewById<LinearLayout>(R.id.configCarButton)
        if (NetUtil.gatewayAddress(this) != car.ip) {
            findViewById<RelativeLayout>(R.id.splitter).visibility = View.GONE
            configBtn.visibility = View.GONE
        }
        configBtn.setOnClickListener { configCar() }
        findViewById<Button>(R.id.connectButton).setOnClickListener { connect() }
    }

    private fun configCar() {
        val pwd = pwdEdit.text.toString()
        showProgress(getString(R.string.check_car_pwd_progress))
        async({
            val ok = CarHttp("${car.ip}:80", pwd).checkPassword().ok
            val version = if (ok) CarHttp("${CarEntity.CAR_AP_IP}:80", pwd).getVersion().let { if (it.ok) it.body else "" } else ""
            ok to version
        }) { (ok, version) ->
            dismissProgress()
            if (!ok) { toast(getString(R.string.car_pwd_err_2)); return@async }
            startActivity(Intent(this, ConfigCarActivity::class.java).putExtra("version", version))
            finish()
        }
    }

    private fun connect() {
        val password = pwdEdit.text.toString()
        if (password.isEmpty()) { toast(getString(R.string.car_pwd_intro)); return }
        val remote = car.remote == true
        val controlPort = NabtoManager.randomPort()
        val rtspPort = NabtoManager.randomPort()
        showProgress(getString(R.string.connect_car_progress))
        async({
            val nabto = app.nabto
            nabto.closeTunnels()
            var video: NabtoManager.TunnelResult? = null
            if (remote) {
                video = nabto.openTunnel(rtspPort, car.id, 554)
                if (!video.ok) return@async Triple(false, video.state, null)
            }
            val ctrl = nabto.openTunnel(controlPort, car.id, 80)
            if (!ctrl.ok) return@async Triple(false, ctrl.state, null)
            runOnUiThread { setProgressMessage(getString(R.string.check_car_pwd_progress)) }
            val httpHost = if (remote) "127.0.0.1:${ctrl.localPort}" else "${car.ip}:80"
            val ok = CarHttp(httpHost, password).checkPassword().ok
            Triple(ok, if (ok) "OK" else "PWD", Pair(ctrl.localPort, video?.localPort ?: 554))
        }) { (ok, state, ports) ->
            dismissProgress()
            if (!ok) {
                if (state == "PWD") toast(getString(R.string.car_pwd_err_2))
                else toast(getString(R.string.connect_car_err) + ": " + state + "]")
                app.nabto.closeTunnels()
                return@async
            }
            car.password = password
            store.setPassword(car.id, password)
            store.save(car)
            car.type = if (remote) CarEntity.TYPE_REMOTE else CarEntity.TYPE_LOCAL
            car.pipe = if (remote) CarEntity.PIPE_SECONDARY else CarEntity.PIPE_PRIMARY
            car.controlPort = ports!!.first
            car.playPort = ports.second
            startActivityForResult(Intent(this, CarActivity::class.java).putExtra("car", car), 1)
        }
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        finish()
    }
}
