package com.ayman.cloudcar.activity

import android.app.Dialog
import android.content.Intent
import android.os.Bundle
import android.view.View
import android.view.WindowManager
import android.view.animation.AnimationUtils
import android.widget.Button
import android.widget.TextView
import com.ayman.cloudcar.R
import com.ayman.cloudcar.core.CarEntity
import com.ayman.cloudcar.core.CarHttp
import com.ayman.cloudcar.core.EasyConfig
import com.ayman.cloudcar.ui.HeaderButtonView
import com.ayman.cloudcar.ui.ProcessingCarView

/**
 * type 1: Easy Config (phone on home Wi-Fi, car in pairing mode)
 * type 2: AP config (phone on the car hotspot, send the home Wi-Fi via HTTP)
 */
class ProcessingCarActivity : BaseActivity() {

    private lateinit var view: ProcessingCarView
    private lateinit var finishBtn: Button
    private lateinit var backBtn: HeaderButtonView
    private var type = 1
    private var ssid = ""
    @Volatile private var success = false
    @Volatile private var processing = false
    private var easyConfig: EasyConfig? = null
    private var dialog: Dialog? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_processing_car)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        type = intent.getIntExtra("type", 1)
        val password = intent.getStringExtra("password") ?: ""
        ssid = intent.getStringExtra("ssid") ?: ""
        val version = intent.getStringExtra("version") ?: ""

        view = findViewById(R.id.processingCarView)
        finishBtn = findViewById(R.id.finishButton)
        backBtn = findViewById(R.id.headerBackButton)
        view.setColor(getColor(if (type == 1) R.color.local_car else R.color.config_car))
        findViewById<TextView>(R.id.headerText).text =
            getString(if (type == 1) R.string.add_wizard else R.string.setting_wizard)

        finishBtn.setOnClickListener {
            if (success && type == 1) startActivity(Intent(this, ProcessCarSuccessActivity::class.java))
            else finish()
        }
        backBtn.setOnClickListener {
            processing = false
            easyConfig?.stop()
            finish()
        }

        processing = true
        if (type == 1) startEasyConfig(password) else startApConfig(password, version)
    }

    private fun startEasyConfig(password: String) {
        val ec = EasyConfig(this)
        easyConfig = ec
        ec.listener = object : EasyConfig.Listener {
            override fun onProgress(percent: Int, ip: String?, mac: String?, id: String?) {
                runOnUiThread {
                    if (ip != null) {
                        success = true
                        showDialog(R.layout.easy_config_successed) {
                            startActivity(Intent(this@ProcessingCarActivity, ProcessCarSuccessActivity::class.java))
                        }
                        return@runOnUiThread
                    }
                    view.setValue(percent); view.invalidate()
                    if (percent >= 100 && !success) showDialog(R.layout.esay_config_failed) { }
                }
            }

            override fun onStop() {
                runOnUiThread { showResult() }
            }
        }
        ec.start(password)
    }

    private fun startApConfig(password: String, version: String) {
        Thread {
            val http = CarHttp("${CarEntity.CAR_AP_IP}:80", "admin")
            val r = if (version.isEmpty()) http.joinWifi2(ssid, password) else http.joinWifi(ssid, password)
            if (r.ok) success = true
        }.start()
        // the car reboots onto the new network: show a 60 s progress like the original
        Thread {
            var v = 0
            while (v <= 100 && processing) {
                val value = v
                runOnUiThread { view.setValue(value); view.invalidate() }
                Thread.sleep(600)
                v++
            }
            runOnUiThread {
                if (!processing || isFinishing) return@runOnUiThread
                if (success) {
                    backBtn.visibility = View.GONE
                    showDialog(R.layout.apconfig_completed) {
                        finishAll(*wizardScreens)
                        finish()
                    }?.findViewById<TextView>(R.id.dialog_text)?.text =
                        getString(R.string.config_completed_tips_1) + " \"" + ssid + "\"" + getString(R.string.config_completed_tips_2)
                }
                showResult()
            }
        }.start()
    }

    private fun showResult() {
        if (isFinishing) return
        processing = false
        view.setValue(100)
        backBtn.visibility = View.GONE
        finishBtn.visibility = View.VISIBLE
        view.setText(getString(if (success) R.string.config_success else R.string.config_fail))
        view.setTextColor(getColor(if (success) R.color.success else R.color.error))
        view.invalidate()
        view.startAnimation(AnimationUtils.loadAnimation(this, R.anim.processing_car))
    }

    private fun showDialog(layout: Int, onOk: () -> Unit): View? {
        if (isFinishing) return null
        dialog?.dismiss()
        val d = Dialog(this, R.style.myDialogTheme)
        val v = layoutInflater.inflate(layout, null)
        v.findViewById<TextView>(R.id.sure_goto_apconfig)?.setOnClickListener { d.dismiss(); onOk() }
        d.setContentView(v)
        d.show()
        dialog = d
        return v
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        processing = false
        easyConfig?.stop()
        @Suppress("DEPRECATION")
        super.onBackPressed()
    }

    override fun onDestroy() {
        processing = false
        easyConfig?.listener = null
        easyConfig?.stop()
        dialog?.dismiss()
        super.onDestroy()
    }
}
