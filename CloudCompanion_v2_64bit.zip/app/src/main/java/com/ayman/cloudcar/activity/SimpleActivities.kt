package com.ayman.cloudcar.activity

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.Bundle
import android.text.InputType
import android.graphics.Typeface
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView
import com.ayman.cloudcar.R
import com.ayman.cloudcar.core.CarEntity
import com.ayman.cloudcar.core.CarStore
import com.ayman.cloudcar.core.NetUtil
import com.ayman.cloudcar.ui.EditTextWithPicture
import com.ayman.cloudcar.ui.HeaderButtonView

class SplashActivity : BaseActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        main.postDelayed({
            startActivity(Intent(this, CarListActivity::class.java))
            finish()
        }, 600)
    }
}

class HelpActivity : BaseActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_help)
        findViewById<HeaderButtonView>(R.id.headerCloseButton).setOnClickListener { finish() }
        val v = try { packageManager.getPackageInfo(packageName, 0).versionName } catch (e: Exception) { "" }
        findViewById<TextView>(R.id.txtView_versionName).text = "Version Name:$v\n"
    }
}

class AddCarActivity : BaseActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_add_car)
        findViewById<HeaderButtonView>(R.id.headerCloseButton).setOnClickListener { finish() }
        findViewById<LinearLayout>(R.id.addLocalCarButton).setOnClickListener {
            startActivity(Intent(this, AddLocalCarActivity::class.java))
        }
        findViewById<LinearLayout>(R.id.addRemoteCarButton).setOnClickListener {
            startActivity(Intent(this, AddRemoteCarActivity::class.java))
        }
    }
}

/** Step 1 of local setup: the Wi-Fi password the car should join (Easy Config). */
class AddLocalCarActivity : BaseActivity() {
    private lateinit var ssidEdit: EditText
    private lateinit var pwd: EditTextWithPicture
    private var ssid = ""
    private var showPwd = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_add_local_car)
        ssidEdit = findViewById(R.id.ssidEditText)
        pwd = findViewById(R.id.wifiPwdEditText)
        pwd.text.typeface = Typeface.DEFAULT
        pwd.text.inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
        pwd.text.hint = getString(R.string.wifi_pwd)
        pwd.imageView.setOnClickListener {
            showPwd = !showPwd
            pwd.text.inputType = if (showPwd) InputType.TYPE_CLASS_TEXT
            else InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
            pwd.text.setSelection(pwd.text.length())
        }
        findViewById<HeaderButtonView>(R.id.headerBackButton).setOnClickListener { finish() }
        findViewById<HeaderButtonView>(R.id.headerCloseButton).setOnClickListener {
            finishAll(AddCarActivity::class.java); finish()
        }
        findViewById<Button>(R.id.nextButton).setOnClickListener {
            val p = pwd.content
            if (!NetUtil.isWifiConnected(this)) { toast(getString(R.string.network_err)); return@setOnClickListener }
            if (!CarEntity.checkRouteName(ssid) || !CarEntity.checkRoutePassword(p)) {
                toast(getString(R.string.ssid_error)); return@setOnClickListener
            }
            startActivity(Intent(this, AddLocalCar2Activity::class.java).putExtra("password", p))
        }
        hideKeyboard()
    }

    override fun onResume() {
        super.onResume()
        if (NetUtil.isWifiConnected(this)) {
            ssid = NetUtil.ssid(this)
            ssidEdit.setText(getString(R.string.wifi) + ": " + ssid)
        } else {
            ssidEdit.setText(getString(R.string.wifi) + ": " + getString(R.string.wifi_disconnected))
        }
    }
}

/** Step 2: instructions (put the car in setup mode), then start Easy Config. */
class AddLocalCar2Activity : BaseActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_add_local_car_2)
        val password = intent.getStringExtra("password") ?: ""
        findViewById<HeaderButtonView>(R.id.headerBackButton).setOnClickListener { finish() }
        findViewById<HeaderButtonView>(R.id.headerCloseButton).setOnClickListener {
            finishAll(AddLocalCarActivity::class.java, AddCarActivity::class.java); finish()
        }
        findViewById<Button>(R.id.nextButton).setOnClickListener {
            startActivity(Intent(this, ProcessingCarActivity::class.java)
                .putExtra("type", 1).putExtra("password", password))
        }
    }
}

class AddRemoteCarActivity : BaseActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_add_remote_car)
        val idEdit = findViewById<EditText>(R.id.carIdEditText)
        findViewById<HeaderButtonView>(R.id.headerBackButton).setOnClickListener { finish() }
        findViewById<HeaderButtonView>(R.id.headerCloseButton).setOnClickListener {
            finishAll(AddCarActivity::class.java); finish()
        }
        findViewById<Button>(R.id.finishButton).setOnClickListener {
            val name = idEdit.text.toString().trim().lowercase()
            if (name.isEmpty()) {
                toast(getString(R.string.car_id_err)); idEdit.requestFocus(); return@setOnClickListener
            }
            val id = CarEntity.getIdFromCarName(name)
            val store = CarStore(this)
            if (store.exists(id)) { toast(getString(R.string.car_exists_err)); return@setOnClickListener }
            store.save(CarEntity(id, "", CarEntity.getCarNameFromId(id), true))
            finishAll(AddCarActivity::class.java); finish()
        }
        hideKeyboard()
    }
}

class ModifyCarActivity : BaseActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_modify_car)
        @Suppress("DEPRECATION")
        val car = intent.getSerializableExtra("car") as CarEntity
        val store = CarStore(this)
        val nameEdit = findViewById<EditText>(R.id.carNameEditText)
        nameEdit.setText(car.name)
        val delete = findViewById<LinearLayout>(R.id.deleteButton)
        if (!store.exists(car.id)) delete.visibility = View.GONE
        findViewById<HeaderButtonView>(R.id.headerCloseButton).setOnClickListener { finish() }
        findViewById<Button>(R.id.finishButton).setOnClickListener {
            val n = nameEdit.text.toString()
            if (n.isEmpty()) { toast(getString(R.string.car_name_err)); nameEdit.requestFocus(); return@setOnClickListener }
            if (n != car.name) {
                car.name = n
                store.save(car)
            }
            finish()
        }
        delete.setOnClickListener {
            store.delete(car.id)
            finish()
        }
        findViewById<LinearLayout>(R.id.copyButton).setOnClickListener {
            val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
            cm.setPrimaryClip(ClipData.newPlainText("car id", car.id))
            if (Build.VERSION.SDK_INT < 33) toast(getString(R.string.copy_car_id_to_clip))
            finish()
        }
    }
}

class ProcessCarSuccessActivity : BaseActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_process_car_success)
        findViewById<Button>(R.id.finishButton).setOnClickListener {
            finishAll(*wizardScreens)
            finish()
        }
    }
}
