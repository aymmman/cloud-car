package com.ayman.cloudcar.core

import android.app.Application

class App : Application() {

    lateinit var nabto: NabtoManager
        private set
    lateinit var player: VideoPlayer
        private set

    override fun onCreate() {
        super.onCreate()
        instance = this
        nabto = NabtoManager(this)
        player = VideoPlayer(this)
        // Modern Android routes traffic to mobile data when the Wi-Fi (the car hotspot)
        // has no internet. Keep the whole process on Wi-Fi whenever Wi-Fi is up.
        NetUtil.keepProcessOnWifi(this)
    }

    companion object {
        lateinit var instance: App
            private set
    }
}
