package com.ayman.cloudcar.core

import org.json.JSONObject
import java.io.Serializable

/** Same fields and helpers as the original CarEntity. */
class CarEntity(
    var id: String = "",
    var ip: String = "",
    var name: String = "",
    /** null = the "add car" tile, true = remote, false = local */
    var remote: Boolean? = null,
    var direct: Boolean = false
) : Serializable {

    var password: String = ""
    var type: Int = TYPE_LOCAL
    var pipe: Int = PIPE_PRIMARY
    var controlPort: Int = 0
    var playPort: Int = 554

    val isAddTile: Boolean get() = remote == null

    fun toJson(): JSONObject = JSONObject().apply {
        put("id", id); put("ip", ip); put("name", name)
        put("remote", remote ?: true); put("direct", direct)
        put("password", password)
    }

    companion object {
        const val TYPE_LOCAL = 0
        const val TYPE_REMOTE = 1
        const val PIPE_PRIMARY = 0     // /cam1/h264   (720p)
        const val PIPE_SECONDARY = 1   // /cam1/h264-1 (VGA)

        // direction codes used by the car protocol
        const val NONE = 0
        const val RIGHT = 1
        const val FRONT_RIGHT = 2
        const val FRONT = 3
        const val LEFT_FRONT = 4
        const val LEFT = 5
        const val BOTTOM_LEFT = 6
        const val BOTTOM = 7
        const val BOTTOM_RIGHT = 8

        const val CAR_AP_IP = "192.168.100.1"

        fun fromJson(o: JSONObject): CarEntity = CarEntity(
            o.optString("id"), o.optString("ip"), o.optString("name"),
            o.optBoolean("remote", true), o.optBoolean("direct", false)
        ).apply { password = o.optString("password") }

        fun getCarNameFromId(id: String): String {
            if (id.contains(".1.ytong.oregon.nabto.net")) return "#" + id.replace(".1.ytong.oregon.nabto.net", "")
            if (id.contains(".1.us.ytong.rakwireless.com")) return id.replace(".1.us.ytong.rakwireless.com", "*1")
            if (id.contains(".2.us.ytong.rakwireless.com")) return id.replace(".2.us.ytong.rakwireless.com", "*2")
            if (id.contains(".2.ytong.rakwireless.com")) return id.replace(".2.ytong.rakwireless.com", "-2")
            if (id.contains(".china.nabto.net")) return id.replace("lx520.", "").replace(".china.nabto.net", "")
            return id.replace(".1.ytong.rakwireless.com", "-1")
        }

        fun getIdFromCarName(name: String): String {
            if (name.startsWith("#")) return name.substring(1) + ".1.ytong.oregon.nabto.net"
            if (name.contains("*1")) return name.substring(0, name.length - 2) + ".1.us.ytong.rakwireless.com"
            if (name.contains("*2")) return name.substring(0, name.length - 2) + ".2.us.ytong.rakwireless.com"
            if (name.contains("-1")) return name.substring(0, name.length - 2) + ".1.ytong.rakwireless.com"
            if (name.contains("-2")) return name.substring(0, name.length - 2) + ".2.ytong.rakwireless.com"
            if (name.startsWith("e09b") || name.startsWith("e087")) return "lx520.$name.china.nabto.net"
            return if (name.contains(".com") || name.contains(".net")) name else "$name.1.ytong.rakwireless.com"
        }

        fun checkRouteName(name: String?): Boolean {
            if (name.isNullOrEmpty()) return true
            return !(name.contains("&") || name.contains("\\") || name.contains("`") ||
                    name.contains("\"") || name.contains("=#"))
        }

        fun checkRoutePassword(password: String?): Boolean = checkRouteName(password)
    }
}
