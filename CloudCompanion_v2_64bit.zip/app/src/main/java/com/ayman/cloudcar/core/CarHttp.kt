package com.ayman.cloudcar.core

import android.util.Base64
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder

/**
 * The car's HTTP API (the original Controller + Lx520 classes).
 * [host] is "ip:port", e.g. "192.168.100.1:80" or "127.0.0.1:<tunnel port>".
 * All calls are blocking: run them off the main thread.
 */
class CarHttp(private val host: String, password: String, private val username: String = "admin") {

    data class Response(val code: Int, val body: String) {
        val ok get() = code == 200
    }

    private val password = if (password.isEmpty()) "admin" else password

    private fun enc(s: String) = URLEncoder.encode(s, "UTF-8")

    fun get(pathAndQuery: String): Response {
        var conn: HttpURLConnection? = null
        return try {
            conn = URL("http://$host$pathAndQuery").openConnection() as HttpURLConnection
            conn.connectTimeout = 5000
            conn.readTimeout = 10000
            conn.useCaches = false
            val auth = Base64.encodeToString("$username:$password".toByteArray(), Base64.NO_WRAP)
            conn.setRequestProperty("Authorization", "Basic $auth")
            val code = conn.responseCode
            val body = if (code == 200) conn.inputStream.bufferedReader().use { it.readText() } else ""
            Response(code, body)
        } catch (e: Exception) {
            Response(0, "")
        } finally {
            conn?.disconnect()
        }
    }

    fun checkPassword() = get("/param.cgi?action=remove&group=userlogin&username=abcde_adsfadf_user100")

    fun updatePassword(newPassword: String) =
        get("/param.cgi?action=update&group=login&username=$username&password=${enc(newPassword)}")

    /** Newer firmware (get_version answers). */
    fun joinWifi(ssid: String, pwd: String) =
        get("/param.cgi?action=update&group=wifi&sta_ssid=${enc(ssid)}&sta_auth_key=${enc(pwd)}")

    /** Older firmware. */
    fun joinWifi2(ssid: String, pwd: String) =
        get("/param.cgi?action=update&group=wifi&dhcp=0&network_type=1&ssid=${enc(ssid)}&auth_key=${enc(pwd)}")

    fun changeVideoResolution(pipe: Int, resolution: Int) =
        get("/server.command?command=set_resol&type=h264&pipe=$pipe&value=$resolution")

    fun getVersion() = get("/server.command?command=get_version")
    fun getWifiList() = get("/server.command?command=get_wifilist")

    companion object {
        /** Parses the SSID list from get_wifilist (JSON "wifimessage" or plain "ssid..." lines). */
        fun parseSsids(body: String): List<String> {
            val out = LinkedHashSet<String>()
            Regex("\"ssid\"\\s*:\\s*\"((?:[^\"\\\\]|\\\\.)*)\"").findAll(body).forEach {
                val s = it.groupValues[1].replace("\\\"", "\"")
                if (s.isNotBlank()) out.add(s)
            }
            if (out.isEmpty()) {
                var src = body
                while (true) {
                    val i = src.indexOf("ssid")
                    if (i == -1) break
                    val j = src.indexOf("\r\n", i + 4)
                    if (j == -1) break
                    val s = src.substring(i + 4, j).trim().trimStart(':', '=').trim()
                    if (s.isNotEmpty()) out.add(s)
                    src = src.substring(j)
                }
            }
            return out.toList()
        }
    }
}
