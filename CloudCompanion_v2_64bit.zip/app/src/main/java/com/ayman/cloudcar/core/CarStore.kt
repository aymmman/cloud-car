package com.ayman.cloudcar.core

import android.content.Context
import org.json.JSONObject

/** Replaces the old SnappyDB (32-bit native) database. Same keys: car_<id>, carpwd_<id>. */
class CarStore(context: Context) {
    private val prefs = context.applicationContext.getSharedPreferences("cars", Context.MODE_PRIVATE)

    fun savedCars(): List<CarEntity> = prefs.all.keys.filter { it.startsWith("car_") }.mapNotNull { key ->
        try { CarEntity.fromJson(JSONObject(prefs.getString(key, "{}")!!)) } catch (e: Exception) { null }
    }

    fun exists(id: String) = prefs.contains("car_$id")

    fun save(car: CarEntity) {
        prefs.edit().putString("car_${car.id}", car.toJson().toString()).apply()
    }

    fun delete(id: String) {
        prefs.edit().remove("car_$id").remove("carpwd_$id").apply()
    }

    fun getPassword(id: String): String? = prefs.getString("carpwd_$id", null)
    fun setPassword(id: String, pwd: String) = prefs.edit().putString("carpwd_$id", pwd).apply()
    fun deletePassword(id: String) = prefs.edit().remove("carpwd_$id").apply()
}
