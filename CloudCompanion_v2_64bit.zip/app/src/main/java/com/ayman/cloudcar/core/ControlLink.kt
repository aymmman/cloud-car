package com.ayman.cloudcar.core

import android.os.Handler
import android.os.Looper
import java.io.DataInputStream
import java.io.OutputStream
import java.net.InetSocketAddress
import java.net.Socket

/**
 * The car's binary control channel (always through the Nabto tunnel on 127.0.0.1).
 * Frame (11 bytes): 01 55 92 09 mode a b c d e xor
 *  mode 1 = drive: a=left motor, b=camera tilt, c=right motor, e=light
 *  mode 3 = wheel speed calibration: a=left, b=right, c=left/2, d=right/2, e=1
 * Status frame (9 bytes): 01 55 92 07 mode ...  mode 1 -> [5]=battery %, [6]=charging
 */
class ControlLink(
    @Volatile private var port: Int,
    /** Called on a worker thread when the socket died; returns a new local tunnel port or null. */
    private val reconnect: (() -> Int?)? = null
) {
    interface Listener {
        fun onBattery(percent: Int, charging: Boolean)
        fun onWheelSpeedResult(success: Boolean)
    }

    @Volatile var direction = 0
    @Volatile var cameraRoll = 0
    @Volatile var light = 0
    var listener: Listener? = null

    @Volatile private var running = false
    @Volatile private var socket: Socket? = null
    @Volatile private var updateBattery = true
    @Volatile private var wheelChange = false
    @Volatile private var leftWheel = 0
    @Volatile private var rightWheel = 0
    private val main = Handler(Looper.getMainLooper())
    private val wheelTimeout = Runnable { finishWheel(false) }

    fun start() {
        if (running) return
        running = true
        Thread({ sendLoop() }, "car-control-tx").start()
    }

    fun stop() {
        running = false
        try { socket?.close() } catch (_: Exception) {}
        main.removeCallbacks(wheelTimeout)
    }

    fun changeWheelSpeed(left: Int, right: Int) {
        leftWheel = left; rightWheel = right
        wheelChange = true
        main.removeCallbacks(wheelTimeout)
        main.postDelayed(wheelTimeout, 10_000)
    }

    private fun finishWheel(success: Boolean) {
        main.removeCallbacks(wheelTimeout)
        if (!wheelChange) return
        wheelChange = false
        main.post { listener?.onWheelSpeedResult(success) }
    }

    private fun connect(): OutputStream? {
        return try {
            val s = Socket()
            s.tcpNoDelay = true
            s.keepAlive = true
            s.connect(InetSocketAddress("127.0.0.1", port), 5000)
            socket = s
            Thread({ receiveLoop(s) }, "car-control-rx").start()
            s.getOutputStream()
        } catch (e: Exception) {
            null
        }
    }

    private fun sendLoop() {
        val msg = byteArrayOf(1, 85, 0x92.toByte(), 9, 1, 0, 0, 0, 0, 0, 8)
        var index = 0
        var out = connect()
        while (running) {
            if (out == null) {
                Thread.sleep(1000)
                if (!running) break
                reconnect?.invoke()?.let { port = it }
                out = connect()
                continue
            }
            if (wheelChange) {
                msg[4] = 3
                msg[5] = leftWheel.toByte()
                msg[6] = rightWheel.toByte()
                msg[7] = (leftWheel / 2).toByte()
                msg[8] = (rightWheel / 2).toByte()
                msg[9] = 1
            } else {
                msg[4] = 1
                var d = direction
                when (direction) {
                    0 -> index = 0
                    // diagonals: alternate "straight" (3 frames) and "turn" (1 frame), like the original
                    2 -> { if (index == 4) index = 0; d = if (index <= 2) 3 else 1; index++ }
                    4 -> { if (index == 4) index = 0; d = if (index <= 2) 3 else 5; index++ }
                    6 -> { if (index == 4) index = 0; d = if (index <= 2) 7 else 5; index++ }
                    8 -> { if (index == 4) index = 0; d = if (index <= 2) 7 else 1; index++ }
                }
                var left = 0; var right = 0
                when (d) {
                    1 -> { left = 1; right = 2 }
                    3 -> { left = 1; right = 1 }
                    5 -> { left = 2; right = 1 }
                    7 -> { left = 2; right = 2 }
                }
                updateBattery = left == 0 || right == 0
                msg[5] = left.toByte()
                msg[6] = cameraRoll.toByte()
                msg[7] = right.toByte()
                msg[8] = 0
                msg[9] = light.toByte()
            }
            var x = 0
            for (i in 3..9) x = x xor msg[i].toInt()
            msg[10] = x.toByte()
            try {
                out.write(msg)
                out.flush()
            } catch (e: Exception) {
                try { socket?.close() } catch (_: Exception) {}
                out = null
                continue
            }
            try { Thread.sleep(200) } catch (_: InterruptedException) {}
        }
        try { socket?.close() } catch (_: Exception) {}
    }

    private fun receiveLoop(s: Socket) {
        try {
            val input = DataInputStream(s.getInputStream())
            val header = intArrayOf(1, 85, 0x92, 7)
            val frame = ByteArray(9)
            var lastBattery = 0L
            while (running && !s.isClosed) {
                // resync on the 4-byte header, then read the rest of the 9-byte frame
                var matched = 0
                while (matched < 4) {
                    val b = input.readUnsignedByte()
                    if (b == header[matched]) { frame[matched] = b.toByte(); matched++ }
                    else matched = if (b == header[0]) { frame[0] = b.toByte(); 1 } else 0
                }
                input.readFully(frame, 4, 5)
                when (frame[4].toInt()) {
                    1 -> {
                        val now = System.currentTimeMillis()
                        if (updateBattery && now - lastBattery > 1200) {
                            lastBattery = now
                            val pct = frame[5].toInt() and 0xff
                            val charging = frame[6].toInt() == 1
                            main.post { listener?.onBattery(pct, charging) }
                        }
                    }
                    3 -> if (wheelChange && frame[5].toInt() == 1) finishWheel(frame[6].toInt() == 1)
                }
            }
        } catch (_: Exception) {
        }
    }
}
