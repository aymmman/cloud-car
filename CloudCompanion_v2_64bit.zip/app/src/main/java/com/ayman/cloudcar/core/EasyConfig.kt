package com.ayman.cloudcar.core

import android.content.Context
import java.net.DatagramPacket
import java.net.DatagramSocket
import java.net.InetAddress
import java.net.InetSocketAddress
import javax.crypto.Cipher
import javax.crypto.spec.SecretKeySpec

/**
 * "Easy config" Wi-Fi provisioning, byte-for-byte the same as the original SDK:
 * the AES-encrypted Wi-Fi password is leaked through multicast group addresses 228.x.y.z.
 */
class EasyConfig(private val ctx: Context) {

    interface Listener {
        /** Called on a background thread. ip/mac/id are non-null when the car answered. */
        fun onProgress(percent: Int, ip: String?, mac: String?, id: String?)
        fun onStop()
    }

    var listener: Listener? = null
    var timeoutMs = 60_000

    @Volatile private var running = false
    private var thread: Thread? = null
    private var encryptedPsk = ByteArray(128)
    private var pskSize = 0
    private val sendBuffer = ByteArray(1024)

    fun start(password: String) {
        val pwd = password.toByteArray()
        val psk = ByteArray(128)
        System.arraycopy(pwd, 0, psk, 0, minOf(pwd.size, 128))
        if (pwd.isNotEmpty()) {
            pskSize = when {
                pwd.size > 112 -> 128
                pwd.size > 96 -> 112
                pwd.size > 80 -> 96
                pwd.size > 64 -> 80
                pwd.size > 48 -> 64
                pwd.size > 32 -> 48
                pwd.size > 16 -> 32
                else -> 16
            }
            encryptedPsk = aesEncrypt(psk, pskSize)
        } else {
            pskSize = 16
        }
        running = true
        thread = Thread { loop() }.also { it.start() }
    }

    fun stop() {
        if (!running) return
        running = false
        listener?.onStop()
    }

    private fun sleep(ms: Long) = try { Thread.sleep(ms) } catch (_: InterruptedException) {}

    private fun loop() {
        val lock = NetUtil.multicastLock(ctx)
        lock.acquire()
        val start = System.currentTimeMillis()
        var lastQuery = 0L
        var socket: DatagramSocket? = null
        var bcast: DatagramSocket? = null
        try {
            socket = DatagramSocket(null).apply { reuseAddress = true; bind(InetSocketAddress(25001)) }
            NetUtil.bindSocket(ctx, socket)
            bcast = DatagramSocket(null).apply {
                reuseAddress = true; broadcast = true; soTimeout = 60; bind(InetSocketAddress(25000))
            }
            NetUtil.bindSocket(ctx, bcast)
            val group = InetAddress.getByName("228.4.5.6")
            while (running) {
                // preamble
                repeat(2) {
                    send(socket, group, 20); sleep(10)
                    send(socket, group, 2); sleep(10)
                }
                // payload: two encrypted bytes per multicast address
                for (i in 1..pskSize / 2) {
                    if (!running) break
                    val b1 = encryptedPsk[(i - 1) * 2].toInt() and 0xff
                    val b2 = encryptedPsk[(i - 1) * 2 + 1].toInt() and 0xff
                    send(socket, InetAddress.getByName("228.$i.$b1.$b2"), 150)
                    sleep(10)
                }
                send(socket, group, 30); sleep(10)

                val elapsed = System.currentTimeMillis() - start
                val percent = minOf(100, (elapsed * 100 / timeoutMs).toInt())
                if (elapsed - lastQuery >= 1000 || percent >= 100) {
                    lastQuery = elapsed
                    var ip: String? = null; var mac: String? = null; var id: String? = null
                    try {
                        val q = "@LT_EASY_DEVICE@".toByteArray()
                        bcast.send(DatagramPacket(q, q.size, InetAddress.getByName("255.255.255.255"), 55555))
                        val buf = ByteArray(1200)
                        val p = DatagramPacket(buf, buf.size)
                        bcast.receive(p)
                        val r = buf.copyOf(p.length)
                        if (r.size > 42) {
                            ip = "${r[32].toInt() and 255}.${r[33].toInt() and 255}.${r[34].toInt() and 255}.${r[35].toInt() and 255}"
                            mac = (36 until 42).joinToString(":") { String.format("%02x", r[it].toInt() and 255) }
                            val len = r[42].toInt() and 255
                            if (r.size - 43 == len) id = String(r, 43, len)
                        }
                    } catch (_: Exception) {
                    }
                    listener?.onProgress(percent, ip, mac, id)
                    if (ip != null || percent >= 100) {
                        stop()
                        break
                    }
                }
            }
        } catch (e: Exception) {
            if (running) stop()
        } finally {
            socket?.close()
            bcast?.close()
            try { lock.release() } catch (_: Exception) {}
        }
    }

    private fun send(s: DatagramSocket, addr: InetAddress, size: Int) {
        try { s.send(DatagramPacket(sendBuffer, size, addr, 12345)) } catch (_: Exception) {}
    }

    private fun aesEncrypt(src: ByteArray, size: Int): ByteArray {
        val dest = ByteArray(128)
        val key = byteArrayOf(52, 42, 7, 44, 28, 57, 60, 86, 32, 44, 9, 47, 27, 96, 54, 49)
        val cipher = Cipher.getInstance("AES/ECB/NoPadding")
        cipher.init(Cipher.ENCRYPT_MODE, SecretKeySpec(key, "AES"))
        val blocks = if (size <= 16) 1 else (size + 15) / 16
        for (j in 0 until blocks) {
            val tmp = ByteArray(16)
            for (i in 0 until 16) {
                val idx = j * 16 + i
                tmp[i] = if (idx < size || size <= 16) src[idx] else 0
            }
            System.arraycopy(cipher.doFinal(tmp), 0, dest, j * 16, 16)
        }
        return dest
    }
}
