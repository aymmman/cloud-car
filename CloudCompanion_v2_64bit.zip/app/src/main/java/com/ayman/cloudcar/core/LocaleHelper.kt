package com.ayman.cloudcar.core

import android.content.Context
import android.content.res.Configuration
import java.util.Locale

/** The six languages of the original app (flag buttons on the car list). */
object LocaleHelper {
    private const val PREFS = "data"
    private const val KEY = "appLanguage"
    val SUPPORTED = listOf("zh", "hk", "en", "es", "ko", "ru")

    fun current(ctx: Context): String {
        val p = ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        p.getString(KEY, null)?.let { if (it in SUPPORTED) return it }
        val sys = Locale.getDefault()
        val lang = when {
            sys.language == "zh" && (sys.country == "HK" || sys.country == "TW" || sys.script == "Hant") -> "hk"
            sys.language in SUPPORTED -> sys.language
            else -> "en" // Arabic and every other language: English instead of the old Chinese default
        }
        p.edit().putString(KEY, lang).apply()
        return lang
    }

    fun set(ctx: Context, lang: String) {
        ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putString(KEY, lang).apply()
    }

    fun locale(lang: String): Locale = when (lang) {
        "zh" -> Locale.SIMPLIFIED_CHINESE
        "hk" -> Locale("zh", "HK")
        "es" -> Locale("es")
        "ko" -> Locale.KOREAN
        "ru" -> Locale("ru")
        else -> Locale.ENGLISH
    }

    fun wrap(base: Context): Context {
        val loc = locale(current(base))
        Locale.setDefault(loc)
        val cfg = Configuration(base.resources.configuration)
        cfg.setLocale(loc)
        cfg.setLayoutDirection(loc)
        return base.createConfigurationContext(cfg)
    }
}
