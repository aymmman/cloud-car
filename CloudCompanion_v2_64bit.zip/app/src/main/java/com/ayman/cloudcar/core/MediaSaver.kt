package com.ayman.cloudcar.core

import android.content.ContentValues
import android.content.Context
import android.graphics.Bitmap
import android.media.MediaScannerConnection
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import java.io.File

/** Saves photos and videos to the phone gallery (Pictures/Movies -> CloudCompanion). */
object MediaSaver {

    private const val FOLDER = "CloudCompanion"

    fun savePhoto(ctx: Context, bmp: Bitmap): String? {
        val name = "${System.currentTimeMillis()}.jpeg"
        return try {
            if (Build.VERSION.SDK_INT >= 29) {
                val v = ContentValues().apply {
                    put(MediaStore.Images.Media.DISPLAY_NAME, name)
                    put(MediaStore.Images.Media.MIME_TYPE, "image/jpeg")
                    put(MediaStore.Images.Media.RELATIVE_PATH, "${Environment.DIRECTORY_PICTURES}/$FOLDER")
                }
                val uri = ctx.contentResolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, v) ?: return null
                ctx.contentResolver.openOutputStream(uri)?.use { bmp.compress(Bitmap.CompressFormat.JPEG, 100, it) }
                "${Environment.DIRECTORY_PICTURES}/$FOLDER/$name"
            } else {
                @Suppress("DEPRECATION")
                val dir = File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_PICTURES), FOLDER)
                dir.mkdirs()
                val f = File(dir, name)
                f.outputStream().use { bmp.compress(Bitmap.CompressFormat.JPEG, 100, it) }
                MediaScannerConnection.scanFile(ctx, arrayOf(f.absolutePath), null, null)
                f.absolutePath
            }
        } catch (e: Exception) { null }
    }

    /** Moves every finished recording from [dir] into the gallery. Returns the last saved path. */
    fun publishVideos(ctx: Context, dir: File): String? {
        var last: String? = null
        dir.listFiles()?.filter { it.isFile && it.length() > 0 }?.forEach { f ->
            val mime = when (f.extension.lowercase()) {
                "mp4" -> "video/mp4"; "mkv" -> "video/x-matroska"; "ts" -> "video/mp2t"; else -> "video/*"
            }
            try {
                if (Build.VERSION.SDK_INT >= 29) {
                    val v = ContentValues().apply {
                        put(MediaStore.Video.Media.DISPLAY_NAME, f.name)
                        put(MediaStore.Video.Media.MIME_TYPE, mime)
                        put(MediaStore.Video.Media.RELATIVE_PATH, "${Environment.DIRECTORY_MOVIES}/$FOLDER")
                    }
                    val uri = ctx.contentResolver.insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, v)
                    if (uri != null) {
                        ctx.contentResolver.openOutputStream(uri)?.use { o -> f.inputStream().use { it.copyTo(o) } }
                        f.delete()
                        last = "${Environment.DIRECTORY_MOVIES}/$FOLDER/${f.name}"
                    }
                } else {
                    @Suppress("DEPRECATION")
                    val outDir = File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_MOVIES), FOLDER)
                    outDir.mkdirs()
                    val dest = File(outDir, f.name)
                    f.copyTo(dest, true); f.delete()
                    MediaScannerConnection.scanFile(ctx, arrayOf(dest.absolutePath), null, null)
                    last = dest.absolutePath
                }
            } catch (_: Exception) {}
        }
        return last
    }
}
