package com.ayman.cloudcar.core

import android.content.Context
import android.util.Log
import com.nabto.api.NabtoAndroidAssetManager
import com.nabto.api.NabtoApi
import com.nabto.api.NabtoStatus
import com.nabto.api.NabtoTunnelState
import com.nabto.api.Session
import com.nabto.api.Tunnel
import java.io.File

/**
 * Same connection method as the original app: a Nabto 4 "guest" session and TCP tunnels
 * to the car (port 80 = control, port 554 = RTSP video), now with the official 64-bit SDK.
 */
class NabtoManager(private val context: Context) {

    data class TunnelResult(val ok: Boolean, val state: String, val localPort: Int)

    private var api: NabtoApi? = null
    private var session: Session? = null
    private val tunnels = mutableListOf<Tunnel>()
    var lastError: String = ""
        private set

    private val okStates = setOf(
        NabtoTunnelState.LOCAL, NabtoTunnelState.REMOTE_P2P,
        NabtoTunnelState.REMOTE_RELAY, NabtoTunnelState.REMOTE_RELAY_MICRO
    )

    private fun installGuestProfile() {
        // The original app shipped Nabto's "guest" certificate; keep it available in both places.
        val users = File(context.filesDir, "nabto/users")
        users.mkdirs()
        for (name in listOf("guest.crt", "guest.key")) {
            val out = File(users, name)
            if (!out.exists()) try {
                context.assets.open("share/nabto/users/$name").use { i -> out.outputStream().use { i.copyTo(it) } }
            } catch (e: Exception) { Log.w(TAG, "guest asset $name: $e") }
        }
    }

    @Synchronized
    private fun ensureSession(): Session? {
        session?.let { return it }
        try {
            if (api == null) {
                val a = NabtoApi(NabtoAndroidAssetManager(context))
                installGuestProfile()
                val st = a.startup()
                if (st != NabtoStatus.OK) {
                    lastError = "startup $st"
                    return null
                }
                api = a
            }
            val a = api!!
            var s = a.openSession("guest", "foobar")
            if (s.status != NabtoStatus.OK) s = a.openSession("guest", "")
            if (s.status != NabtoStatus.OK) s = a.openSessionBare()
            if (s.status != NabtoStatus.OK) {
                lastError = "session ${s.status}"
                return null
            }
            session = s
            return s
        } catch (t: Throwable) {
            lastError = t.toString()
            Log.e(TAG, "Nabto init failed", t)
            return null
        }
    }

    /** Blocking. Opens localhost:[localPort] -> [nabtoHost]:127.0.0.1:[remotePort]. */
    fun openTunnel(localPort: Int, nabtoHost: String, remotePort: Int): TunnelResult {
        val s = ensureSession() ?: return TunnelResult(false, "FAILED", localPort)
        val a = api ?: return TunnelResult(false, "FAILED", localPort)
        return try {
            val t = a.tunnelOpenTcp(localPort, nabtoHost, "127.0.0.1", remotePort, s)
            if (t.status != NabtoStatus.OK) return TunnelResult(false, "FAILED", localPort)
            val info = a.tunnelWait(t, 250, 50_000)
            val state = info.tunnelState
            val ok = info.status == NabtoStatus.OK && state in okStates
            if (ok) {
                synchronized(tunnels) { tunnels.add(t) }
                val port = if (info.port > 0) info.port else localPort
                TunnelResult(true, state.name, port)
            } else {
                try { a.tunnelClose(t) } catch (_: Throwable) {}
                val name = state?.name ?: "UNKNOWN"
                TunnelResult(false, if (name == "CONNECTING") "CONNECT_TIMEOUT" else name, localPort)
            }
        } catch (t: Throwable) {
            Log.e(TAG, "tunnel failed", t)
            TunnelResult(false, "FAILED", localPort)
        }
    }

    fun closeTunnels() {
        val a = api ?: return
        synchronized(tunnels) {
            tunnels.forEach { try { a.tunnelClose(it) } catch (_: Throwable) {} }
            tunnels.clear()
        }
    }

    companion object {
        private const val TAG = "NabtoManager"
        fun randomPort(): Int = (Math.random() * 60531).toInt() + 5000
    }
}
