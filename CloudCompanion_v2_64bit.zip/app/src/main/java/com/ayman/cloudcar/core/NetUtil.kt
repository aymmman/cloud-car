package com.ayman.cloudcar.core

import android.annotation.SuppressLint
import android.content.Context
import android.net.ConnectivityManager
import android.net.LinkProperties
import android.net.Network
import android.net.NetworkCapabilities
import android.net.NetworkRequest
import android.net.wifi.WifiManager
import java.net.DatagramSocket
import java.net.Inet4Address
import java.net.InetAddress

object NetUtil {

    @Volatile private var wifiNet: Network? = null

    private fun cm(ctx: Context) =
        ctx.applicationContext.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager

    private fun wm(ctx: Context) =
        ctx.applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager

    fun keepProcessOnWifi(ctx: Context) {
        val cm = cm(ctx)
        val req = NetworkRequest.Builder().addTransportType(NetworkCapabilities.TRANSPORT_WIFI).build()
        try {
            cm.registerNetworkCallback(req, object : ConnectivityManager.NetworkCallback() {
                override fun onAvailable(network: Network) {
                    wifiNet = network
                    try { cm.bindProcessToNetwork(network) } catch (_: Exception) {}
                }
                override fun onLost(network: Network) {
                    if (wifiNet == network) {
                        wifiNet = null
                        try { cm.bindProcessToNetwork(null) } catch (_: Exception) {}
                    }
                }
            })
        } catch (_: Exception) {}
    }

    @Suppress("DEPRECATION")
    fun wifiNetwork(ctx: Context): Network? {
        wifiNet?.let { return it }
        val cm = cm(ctx)
        return cm.allNetworks.firstOrNull {
            cm.getNetworkCapabilities(it)?.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) == true
        }
    }

    fun isWifiConnected(ctx: Context) = wifiNetwork(ctx) != null

    private fun wifiLink(ctx: Context): LinkProperties? = wifiNetwork(ctx)?.let { cm(ctx).getLinkProperties(it) }

    /** Binds a UDP socket to the Wi-Fi network so broadcasts never leave through mobile data. */
    fun bindSocket(ctx: Context, socket: DatagramSocket) {
        try { wifiNetwork(ctx)?.bindSocket(socket) } catch (_: Exception) {}
    }

    @Suppress("DEPRECATION")
    fun gatewayAddress(ctx: Context): String {
        wifiLink(ctx)?.routes?.forEach { r ->
            val gw = r.gateway
            if (r.isDefaultRoute && gw is Inet4Address && !gw.isAnyLocalAddress) return gw.hostAddress ?: ""
        }
        return try {
            val g = wm(ctx).dhcpInfo.gateway
            if (g == 0) "" else "${g and 0xff}.${g shr 8 and 0xff}.${g shr 16 and 0xff}.${g shr 24 and 0xff}"
        } catch (_: Exception) { "" }
    }

    fun broadcastAddress(ctx: Context): InetAddress {
        wifiLink(ctx)?.linkAddresses?.forEach { la ->
            val a = la.address
            if (a is Inet4Address) {
                val b = a.address
                val ip = (b[0].toInt() and 0xff shl 24) or (b[1].toInt() and 0xff shl 16) or
                        (b[2].toInt() and 0xff shl 8) or (b[3].toInt() and 0xff)
                val mask = if (la.prefixLength == 0) 0 else (-1 shl (32 - la.prefixLength))
                val bc = ip or mask.inv()
                return InetAddress.getByAddress(
                    byteArrayOf((bc shr 24).toByte(), (bc shr 16).toByte(), (bc shr 8).toByte(), bc.toByte())
                )
            }
        }
        return InetAddress.getByName("255.255.255.255")
    }

    @SuppressLint("MissingPermission")
    @Suppress("DEPRECATION")
    fun ssid(ctx: Context): String {
        return try {
            val s = wm(ctx).connectionInfo?.ssid ?: return ""
            if (s == "<unknown ssid>") "" else s.trim('"')
        } catch (_: Exception) { "" }
    }

    @SuppressLint("MissingPermission")
    @Suppress("DEPRECATION")
    fun bssid(ctx: Context): String = try { wm(ctx).connectionInfo?.bssid ?: "" } catch (_: Exception) { "" }

    fun multicastLock(ctx: Context): WifiManager.MulticastLock =
        wm(ctx).createMulticastLock("cloudcompanion").apply { setReferenceCounted(false) }
}
