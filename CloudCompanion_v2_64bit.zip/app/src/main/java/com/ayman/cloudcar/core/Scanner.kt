package com.ayman.cloudcar.core

import android.content.Context
import java.net.DatagramPacket
import java.net.DatagramSocket
import java.net.InetAddress
import java.net.SocketTimeoutException

/** LAN discovery exactly like the original: UDP broadcast to port 5570, device id at byte 19. */
object Scanner {

    private val PROBE = byteArrayOf(0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 42, 0)
    private const val PORT = 5570
    private const val ID_BEGIN = 18

    /** Blocking. Returns ip -> deviceId. */
    fun scan(ctx: Context): Map<String, String> {
        val found = LinkedHashMap<String, String>()
        if (!NetUtil.isWifiConnected(ctx)) return found
        val lock = NetUtil.multicastLock(ctx)
        try {
            lock.acquire()
            val targets = linkedSetOf(NetUtil.broadcastAddress(ctx), InetAddress.getByName("255.255.255.255"))
            repeat(7) {
                var socket: DatagramSocket? = null
                try {
                    socket = DatagramSocket()
                    NetUtil.bindSocket(ctx, socket)
                    socket.broadcast = true
                    socket.soTimeout = 200
                    for (t in targets) socket.send(DatagramPacket(PROBE, PROBE.size, t, PORT))
                    repeat(10) {
                        try {
                            val buf = ByteArray(1024)
                            val p = DatagramPacket(buf, buf.size)
                            socket.receive(p)
                            val ip = p.address.hostAddress ?: ""
                            if (ip.isNotEmpty() && !found.containsKey(ip) && p.length > ID_BEGIN) {
                                var end = -1
                                for (i in ID_BEGIN until p.length) if (buf[i] == 0.toByte()) { end = i; break }
                                if (end == -1) end = p.length
                                if (end > ID_BEGIN + 1) found[ip] = String(buf, ID_BEGIN + 1, end - ID_BEGIN - 1)
                            }
                        } catch (_: SocketTimeoutException) {
                        }
                    }
                } catch (_: Exception) {
                } finally {
                    socket?.close()
                }
            }
        } finally {
            try { lock.release() } catch (_: Exception) {}
        }
        return found
    }
}
