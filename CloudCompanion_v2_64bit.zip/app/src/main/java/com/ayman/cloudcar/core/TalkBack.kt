package com.ayman.cloudcar.core

import android.annotation.SuppressLint
import android.media.AudioFormat
import android.media.AudioRecord
import android.media.MediaRecorder
import java.io.ByteArrayOutputStream
import java.net.InetSocketAddress
import java.net.Socket

/**
 * Push-to-talk: records 8 kHz mono while the button is held, converts to G.711 u-law and
 * POSTs it to the car's /audio.input (same as the original RecordAudio + SendAudio).
 */
class TalkBack {

    @Volatile private var recording = false
    private var thread: Thread? = null

    @SuppressLint("MissingPermission")
    fun begin(host: String, port: Int): Boolean {
        if (recording) return false
        recording = true
        thread = Thread {
            val min = AudioRecord.getMinBufferSize(8000, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT)
            val rec = try {
                AudioRecord(MediaRecorder.AudioSource.MIC, 8000, AudioFormat.CHANNEL_IN_MONO,
                    AudioFormat.ENCODING_PCM_16BIT, min * 2)
            } catch (e: Exception) { null }
            if (rec == null || rec.state != AudioRecord.STATE_INITIALIZED) { recording = false; return@Thread }
            val data = ByteArrayOutputStream()
            val buf = ShortArray(min)
            rec.startRecording()
            while (recording) {
                val n = rec.read(buf, 0, buf.size)
                for (i in 0 until n) data.write(linear2ulaw(buf[i].toInt()))
            }
            try { rec.stop() } catch (_: Exception) {}
            rec.release()
            send(host, port, data.toByteArray())
        }.also { it.start() }
        return true
    }

    fun stop() { recording = false }

    private fun send(host: String, port: Int, bytes: ByteArray) {
        if (bytes.isEmpty()) return
        try {
            Socket().use { s ->
                s.connect(InetSocketAddress(host, port), 5000)
                val out = s.getOutputStream()
                val header = "POST /audio.input HTTP/1.1\r\nHost: $host\r\nContent-Type: audio/wav\r\n" +
                        "Content-Length: ${bytes.size}\r\nAccept: */*\r\n\r\n"
                out.write(header.toByteArray())
                out.flush()
                Thread.sleep(100)
                var pos = 0
                while (pos < bytes.size) {
                    val n = minOf(4096, bytes.size - pos)
                    out.write(bytes, pos, n)
                    pos += n
                }
                out.flush()
                Thread.sleep(300)
            }
        } catch (_: Exception) {
        }
    }

    companion object {
        private const val BIAS = 0x84
        private val SEG_END = intArrayOf(0xFF, 0x1FF, 0x3FF, 0x7FF, 0xFFF, 0x1FFF, 0x3FFF, 0x7FFF)

        fun linear2ulaw(pcm: Int): Int {
            val mask: Int
            var v: Int
            if (pcm < 0) { v = BIAS - pcm; mask = 0x7F } else { v = pcm + BIAS; mask = 0xFF }
            if (v > 0x7FFF) v = 0x7FFF
            var seg = 0
            while (seg < 8 && v > SEG_END[seg]) seg++
            if (seg >= 8) return 0x7F xor mask
            val u = (seg shl 4) or ((v shr (seg + 3)) and 0xF)
            return (u xor mask) and 0xFF
        }
    }
}
