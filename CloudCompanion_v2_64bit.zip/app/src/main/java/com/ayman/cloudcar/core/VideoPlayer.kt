package com.ayman.cloudcar.core

import android.content.Context
import android.graphics.Bitmap
import android.net.Uri
import android.os.Handler
import android.os.Looper
import android.util.Log
import android.view.TextureView
import android.view.View
import android.view.ViewGroup
import org.videolan.libvlc.LibVLC
import org.videolan.libvlc.Media
import org.videolan.libvlc.MediaPlayer
import org.videolan.libvlc.util.VLCVideoLayout
import java.io.File
import java.net.URLEncoder

/**
 * Replaces the original 32-bit libdemo.sdk.so RTSP player with 64-bit libVLC.
 * Lives in the Application so it survives screen rotation, like the original Module/Player.
 */
class VideoPlayer(private val context: Context) {

    enum class State { IDLE, PREPARING, PLAYING }

    var state = State.IDLE
        private set
    var onVideoReceived: (() -> Unit)? = null
    var onError: (() -> Unit)? = null

    private val main = Handler(Looper.getMainLooper())
    private var libVlc: LibVLC? = null
    private var player: MediaPlayer? = null
    private var layout: VLCVideoLayout? = null

    private var url = ""
    private var tcp = false
    private var user = "admin"
    private var pass = "admin"
    private var retries = 0
    var isRecording = false
        private set
    var recordDir: File? = null
        private set

    private fun ensurePlayer(): MediaPlayer {
        player?.let { return it }
        val vlc = LibVLC(context, arrayListOf(
            "--network-caching=250",
            "--rtsp-frame-buffer-size=500000",
            "--no-drop-late-frames",
            "--no-skip-frames",
            "--audio-time-stretch"
        ))
        libVlc = vlc
        val mp = MediaPlayer(vlc)
        mp.setEventListener { ev ->
            when (ev.type) {
                MediaPlayer.Event.Vout -> if (ev.voutCount > 0 && state != State.PLAYING) {
                    state = State.PLAYING
                    retries = 0
                    main.post { onVideoReceived?.invoke() }
                }
                MediaPlayer.Event.EncounteredError -> handleError()
                MediaPlayer.Event.EndReached -> handleError()
            }
        }
        player = mp
        return mp
    }

    private fun handleError() {
        Log.w(TAG, "stream error on $url (tcp=$tcp)")
        if (state == State.IDLE) return
        state = State.PREPARING
        if (retries < 3) {
            retries++
            // Local UDP RTP is often blocked on new phones: fall back to RTSP-over-TCP.
            if (!tcp && retries >= 1) tcp = true
            main.postDelayed({ if (state != State.IDLE) startMedia() }, 1500)
        } else {
            main.post { onError?.invoke() }
        }
    }

    fun attach(view: VLCVideoLayout) {
        val mp = ensurePlayer()
        if (layout === view) return
        try { mp.detachViews() } catch (_: Exception) {}
        mp.attachViews(view, null, false, true)
        layout = view
    }

    fun detach() {
        try { player?.detachViews() } catch (_: Exception) {}
        layout = null
    }

    /** Builds the same URLs the original SDK used. */
    fun play(host: String, port: Int, pipe: Int, useTcp: Boolean, username: String, password: String) {
        val path = if (pipe == CarEntity.PIPE_PRIMARY) "/cam1/h264" else "/cam1/h264-1"
        user = username
        pass = password.ifEmpty { "admin" }
        url = "rtsp://$host:$port$path"
        tcp = useTcp
        retries = 0
        state = State.PREPARING
        startMedia()
    }

    private fun startMedia() {
        val mp = ensurePlayer()
        val vlc = libVlc ?: return
        val auth = "${enc(user)}:${enc(pass)}@"
        val full = url.replaceFirst("rtsp://", "rtsp://$auth")
        val media = Media(vlc, Uri.parse(full))
        media.setHWDecoderEnabled(true, false)
        media.addOption(":network-caching=250")
        media.addOption(":rtsp-user=$user")
        media.addOption(":rtsp-pwd=$pass")
        if (tcp) media.addOption(":rtsp-tcp")
        try { mp.stop() } catch (_: Exception) {}
        mp.setMedia(media)
        media.release()
        mp.play()
    }

    fun stop() {
        if (isRecording) stopRecord()
        state = State.IDLE
        main.removeCallbacksAndMessages(null)
        try { player?.stop() } catch (_: Exception) {}
    }

    fun setVolume(percent: Int) { player?.setVolume(percent) }

    /** Grabs the current frame from the TextureView used by libVLC. */
    fun takePhoto(): Bitmap? {
        val tv = layout?.let { findTexture(it) } ?: return null
        return try { tv.bitmap } catch (_: Exception) { null }
    }

    private fun findTexture(v: View): TextureView? {
        if (v is TextureView) return v
        if (v is ViewGroup) for (i in 0 until v.childCount) findTexture(v.getChildAt(i))?.let { return it }
        return null
    }

    /** libVLC records the incoming stream into [dir]. Called by reflection to stay version-safe. */
    fun beginRecord(dir: File): Boolean {
        val mp = player ?: return false
        dir.mkdirs()
        val ok = invokeRecord(mp, dir.absolutePath)
        if (ok) { isRecording = true; recordDir = dir }
        return ok
    }

    fun stopRecord(): Boolean {
        val mp = player ?: return false
        isRecording = false
        return invokeRecord(mp, null)
    }

    private fun invokeRecord(mp: MediaPlayer, dir: String?): Boolean = try {
        val m = MediaPlayer::class.java.getMethod("record", String::class.java)
        (m.invoke(mp, dir) as? Boolean) ?: true
    } catch (t: Throwable) {
        Log.e(TAG, "record not supported", t)
        false
    }

    private fun enc(s: String) = URLEncoder.encode(s, "UTF-8")

    companion object { private const val TAG = "VideoPlayer" }
}
