package com.ayman.cloudcar.ui

import android.content.Context
import android.content.Intent
import android.util.AttributeSet
import android.view.LayoutInflater
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.animation.Animation
import android.view.animation.ScaleAnimation
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import com.ayman.cloudcar.R
import com.ayman.cloudcar.activity.AddCarActivity
import com.ayman.cloudcar.activity.ConnectCarActivity
import com.ayman.cloudcar.activity.ModifyCarActivity
import com.ayman.cloudcar.core.CarEntity

/** Simple wrapping layout (replacement for org.apmem FlowLayout). */
class FlowLayout @JvmOverloads constructor(ctx: Context, attrs: AttributeSet? = null) : ViewGroup(ctx, attrs) {

    override fun onMeasure(wSpec: Int, hSpec: Int) {
        val maxW = MeasureSpec.getSize(wSpec) - paddingLeft - paddingRight
        var x = 0; var y = 0; var rowH = 0
        for (i in 0 until childCount) {
            val c = getChildAt(i)
            if (c.visibility == GONE) continue
            measureChildWithMargins(c, wSpec, 0, hSpec, 0)
            val lp = c.layoutParams as ViewGroup.MarginLayoutParams
            val cw = c.measuredWidth + lp.leftMargin + lp.rightMargin
            val ch = c.measuredHeight + lp.topMargin + lp.bottomMargin
            if (x + cw > maxW && x > 0) { x = 0; y += rowH; rowH = 0 }
            x += cw; rowH = maxOf(rowH, ch)
        }
        setMeasuredDimension(MeasureSpec.getSize(wSpec), resolveSize(y + rowH + paddingTop + paddingBottom, hSpec))
    }

    override fun onLayout(changed: Boolean, l: Int, t: Int, r: Int, b: Int) {
        val maxW = r - l - paddingLeft - paddingRight
        var x = 0; var y = 0; var rowH = 0
        for (i in 0 until childCount) {
            val c = getChildAt(i)
            if (c.visibility == GONE) continue
            val lp = c.layoutParams as ViewGroup.MarginLayoutParams
            val cw = c.measuredWidth + lp.leftMargin + lp.rightMargin
            val ch = c.measuredHeight + lp.topMargin + lp.bottomMargin
            if (x + cw > maxW && x > 0) { x = 0; y += rowH; rowH = 0 }
            val cl = paddingLeft + x + lp.leftMargin
            val ct = paddingTop + y + lp.topMargin
            c.layout(cl, ct, cl + c.measuredWidth, ct + c.measuredHeight)
            x += cw; rowH = maxOf(rowH, ch)
        }
    }

    override fun generateDefaultLayoutParams(): ViewGroup.LayoutParams =
        ViewGroup.MarginLayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT)
    override fun generateLayoutParams(attrs: AttributeSet?): ViewGroup.LayoutParams = ViewGroup.MarginLayoutParams(context, attrs)
    override fun generateLayoutParams(p: ViewGroup.LayoutParams?): ViewGroup.LayoutParams = ViewGroup.MarginLayoutParams(p)
    override fun checkLayoutParams(p: ViewGroup.LayoutParams?): Boolean = p is ViewGroup.MarginLayoutParams
}

class CarListItemView(ctx: Context) : LinearLayout(ctx) {
    private val button: ButtonView
    private val nameView: TextView
    private var car: CarEntity? = null

    init {
        addView(LayoutInflater.from(ctx).inflate(R.layout.view_car_list_item, this, false))
        button = findViewById(R.id.carButtonView)
        nameView = findViewById(R.id.nameTextView)
        val downAnim = ScaleAnimation(1f, 0.95f, 1f, 0.95f, Animation.RELATIVE_TO_SELF, 0.5f, Animation.RELATIVE_TO_SELF, 0.5f)
            .apply { duration = 50; fillAfter = true }
        val upAnim = ScaleAnimation(0.95f, 1f, 0.95f, 1f, Animation.RELATIVE_TO_SELF, 0.5f, Animation.RELATIVE_TO_SELF, 0.5f)
            .apply { duration = 50; fillAfter = true }
        button.setOnTouchListener { _, e ->
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> { button.startAnimation(downAnim); button.background?.alpha = 200 }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> { button.startAnimation(upAnim); button.background?.alpha = 255 }
            }
            false
        }
    }

    fun setCarEntity(c: CarEntity) {
        car = c
        nameView.text = c.name
        if (c.isAddTile) {
            button.setBackgroundResource(R.drawable.bg_car_list_item_add)
            button.setOnLongClickListener(null)
        } else {
            button.setBackgroundResource(
                when {
                    c.remote == true -> R.drawable.bg_car_list_item_remote
                    c.direct -> R.drawable.bg_car_list_item_direct
                    else -> R.drawable.bg_car_list_item_local
                }
            )
            button.setOnLongClickListener {
                context.startActivity(Intent(context, ModifyCarActivity::class.java).putExtra("car", c))
                true
            }
        }
        button.setOnClickListener {
            if (c.isAddTile) context.startActivity(Intent(context, AddCarActivity::class.java))
            else context.startActivity(Intent(context, ConnectCarActivity::class.java).putExtra("car", c))
        }
    }

    fun setSize(size: Int) {
        button.layoutParams = LinearLayout.LayoutParams(size, size)
        val lp = nameView.layoutParams as LinearLayout.LayoutParams
        lp.width = size
        nameView.layoutParams = lp
    }
}

class CarListView @JvmOverloads constructor(ctx: Context, attrs: AttributeSet? = null) : ScrollView(ctx, attrs) {
    private val main: FlowLayout

    init {
        addView(LayoutInflater.from(ctx).inflate(R.layout.view_car_list, this, false))
        main = findViewById(R.id.mainLayout)
    }

    fun setData(data: List<CarEntity>) {
        main.removeAllViews()
        val fill = Runnable {
            val w = main.width - main.paddingLeft - main.paddingRight
            val size = w / 3 - 50
            for (c in data) {
                val item = CarListItemView(context)
                item.setCarEntity(c)
                val lp = ViewGroup.MarginLayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT)
                lp.setMargins(25, 25, 25, 50)
                main.addView(item, lp)
                item.setSize(size)
            }
        }
        if (main.width == 0) {
            main.viewTreeObserver.addOnGlobalLayoutListener(object : android.view.ViewTreeObserver.OnGlobalLayoutListener {
                override fun onGlobalLayout() {
                    main.viewTreeObserver.removeOnGlobalLayoutListener(this)
                    fill.run()
                }
            })
            main.requestLayout()
        } else fill.run()
    }
}
