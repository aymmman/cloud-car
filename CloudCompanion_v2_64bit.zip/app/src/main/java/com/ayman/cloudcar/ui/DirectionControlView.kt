package com.ayman.cloudcar.ui

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Matrix
import android.graphics.Paint
import android.util.AttributeSet
import android.view.MotionEvent
import android.view.View
import com.ayman.cloudcar.R

/** Landscape two-thumb control: left pad = left/right, right pad = forward/back (multi-touch). */
class DirectionControlView @JvmOverloads constructor(ctx: Context, attrs: AttributeSet? = null, def: Int = 0) :
    View(ctx, attrs, def) {

    fun interface OnDirectionUpdateListener { fun onValueChanged(direction: Int) }

    var listener: OnDirectionUpdateListener? = null
    private val dim = Paint().apply { alpha = 125 }
    private var h = 0
    private var leftBg: Bitmap? = null
    private var rightBg: Bitmap? = null
    private var leftC: Bitmap? = null
    private var rightC: Bitmap? = null
    private var frontC: Bitmap? = null
    private var bottomC: Bitmap? = null
    private var lp = false; private var rp = false; private var fp = false; private var bp = false

    override fun onMeasure(w: Int, hs: Int) {
        val width = MeasureSpec.getSize(w)
        setMeasuredDimension(width, width / 4)
    }

    override fun onSizeChanged(w: Int, hh: Int, ow: Int, oh: Int) {
        super.onSizeChanged(w, hh, ow, oh)
        h = hh
        if (h <= 0) return
        val bg = Bitmap.createScaledBitmap(BitmapFactory.decodeResource(resources, R.drawable.joystick_bg_2), h, h, true)
        val m = Matrix()
        leftBg = bg
        m.postRotate(90f); rightBg = Bitmap.createBitmap(bg, 0, 0, h, h, m, true)
        val arrow = Bitmap.createScaledBitmap(BitmapFactory.decodeResource(resources, R.drawable.joystick_arrow_2), h, h, true)
        leftC = arrow
        val m2 = Matrix()
        m2.postRotate(90f); frontC = Bitmap.createBitmap(arrow, 0, 0, h, h, m2, true)
        m2.postRotate(90f); rightC = Bitmap.createBitmap(arrow, 0, 0, h, h, m2, true)
        m2.postRotate(90f); bottomC = Bitmap.createBitmap(arrow, 0, 0, h, h, m2, true)
    }

    override fun onDraw(canvas: Canvas) {
        val rx = (width - h).toFloat()
        val lb = leftBg ?: return
        canvas.drawBitmap(lb, 0f, 0f, null)
        canvas.drawBitmap(rightBg!!, rx, 0f, null)
        canvas.drawBitmap(frontC!!, rx, 0f, if (fp) null else dim)
        canvas.drawBitmap(bottomC!!, rx, 0f, if (bp) null else dim)
        canvas.drawBitmap(leftC!!, 0f, 0f, if (lp) null else dim)
        canvas.drawBitmap(rightC!!, 0f, 0f, if (rp) null else dim)
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        if (!isEnabled) return true
        val rx = width - h
        lp = false; rp = false; fp = false; bp = false
        val am = e.actionMasked
        if (am != MotionEvent.ACTION_UP && am != MotionEvent.ACTION_CANCEL) {
            for (i in 0 until e.pointerCount) {
                if (am == MotionEvent.ACTION_POINTER_UP && i == e.actionIndex) continue
                val x = e.getX(i); val y = e.getY(i)
                if (x >= 0 && x <= h / 2f) lp = true
                if (x >= h / 2f && x <= h) rp = true
                if (x >= rx && x <= width && y >= 0 && y <= h / 2f) fp = true
                if (x >= rx && x <= width && y >= h / 2f && y <= h) bp = true
            }
        }
        val d = when {
            lp -> if (fp) 4 else if (bp) 6 else 5
            rp -> if (fp) 2 else if (bp) 8 else 1
            fp -> 3
            bp -> 7
            else -> 0
        }
        invalidate()
        listener?.onValueChanged(d)
        return true
    }
}
