package com.ayman.cloudcar.ui

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Matrix
import android.graphics.PointF
import android.util.AttributeSet
import android.view.MotionEvent
import android.view.View
import com.ayman.cloudcar.R
import kotlin.math.atan
import kotlin.math.sqrt

/** Port of the original joystick: 8 directions, 70% power threshold. */
class JoystickView @JvmOverloads constructor(ctx: Context, attrs: AttributeSet? = null, def: Int = 0) :
    View(ctx, attrs, def) {

    fun interface OnJoystickMoveListener { fun onValueChanged(angle: Int, power: Int, direction: Int) }

    private val rad = 57.2957795
    private var cx = 0.0
    private var cy = 0.0
    private var ready = false
    private var lastAngle = 0
    private var lastPower = 0
    private val pos = PointF()
    private val threshold = 70
    private var radius = 1
    private var bg: Bitmap? = null
    private var ctrl: Bitmap? = null
    private var up: Bitmap? = null
    private var down: Bitmap? = null
    private var left: Bitmap? = null
    private var right: Bitmap? = null
    var listener: OnJoystickMoveListener? = null
    var useSensor = false
        set(v) { field = v; if (!v) resetCtrlPos() }

    private fun angle(): Int {
        val a: Int = if (pos.x > cx) {
            when {
                pos.y < cy -> (atan((pos.y - cy) / (pos.x - cx)) * rad + 90).toInt()
                pos.y > cy -> (atan((pos.y - cy) / (pos.x - cx)) * rad).toInt() + 90
                else -> 90
            }
        } else if (pos.x >= cx) {
            if (pos.y <= cy) 0 else if (lastAngle < 0) -180 else 180
        } else {
            when {
                pos.y < cy -> (atan((pos.y - cy) / (pos.x - cx)) * rad - 90).toInt()
                pos.y > cy -> (atan((pos.y - cy) / (pos.x - cx)) * rad).toInt() - 90
                else -> -90
            }
        }
        lastAngle = a
        return a
    }

    private fun direction(): Int {
        if (lastPower == 0 && lastAngle == 0) return 0
        val a = when {
            lastAngle <= 0 -> -lastAngle + 90
            lastAngle <= 90 -> 90 - lastAngle
            else -> 360 - (lastAngle - 90)
        }
        val d = (a + 22) / 45 + 1
        return if (d > 8) 1 else d
    }

    private fun power(): Int {
        val dx = pos.x - cx; val dy = pos.y - cy
        lastPower = (100.0 * sqrt(dx * dx + dy * dy) / radius).toInt()
        return lastPower
    }

    override fun onMeasure(w: Int, h: Int) {
        fun m(s: Int) = if (MeasureSpec.getMode(s) == MeasureSpec.UNSPECIFIED) 200 else MeasureSpec.getSize(s)
        val s = minOf(m(w), m(h)); setMeasuredDimension(s, s)
    }

    override fun onSizeChanged(w: Int, h: Int, ow: Int, oh: Int) {
        super.onSizeChanged(w, h, ow, oh)
        ready = false
        if (w == 0 || h == 0) return
        cx = w / 2.0; cy = h / 2.0
        pos.set(cx.toFloat(), cy.toFloat())
        radius = maxOf(1, (0.3 * (minOf(w, h) / 2)).toInt())
        bg = Bitmap.createScaledBitmap(BitmapFactory.decodeResource(resources, R.drawable.joystick_bg), w, h, true)
        ctrl = Bitmap.createScaledBitmap(BitmapFactory.decodeResource(resources, R.drawable.joystick_ctrl),
            (w * 0.35).toInt(), (h * 0.35).toInt(), true)
        val arrow = Bitmap.createScaledBitmap(BitmapFactory.decodeResource(resources, R.drawable.joystick_arrow), w, h, true)
        down = arrow
        val m = Matrix()
        m.postRotate(90f); left = Bitmap.createBitmap(arrow, 0, 0, w, h, m, true)
        m.postRotate(90f); up = Bitmap.createBitmap(arrow, 0, 0, w, h, m, true)
        m.postRotate(90f); right = Bitmap.createBitmap(arrow, 0, 0, w, h, m, true)
        ready = true
    }

    override fun onDraw(canvas: Canvas) {
        if (!ready) return
        canvas.drawBitmap(bg!!, 0f, 0f, null)
        power(); angle()
        val d = direction()
        if (lastPower > threshold) {
            if (d == 3 || d == 2 || d == 4) canvas.drawBitmap(up!!, 0f, 0f, null)
            if (d == 7 || d == 6 || d == 8) canvas.drawBitmap(down!!, 0f, 0f, null)
            if (d == 5 || d == 4 || d == 6) canvas.drawBitmap(left!!, 0f, 0f, null)
            if (d == 1 || d == 2 || d == 8) canvas.drawBitmap(right!!, 0f, 0f, null)
        }
        val c = ctrl!!
        canvas.drawBitmap(c, pos.x - c.width / 2f, pos.y - c.height / 2f, null)
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        if (!isEnabled) return true
        val x0 = width / 2f; val y0 = height / 2f
        pos.set(e.x, e.y)
        val dist = sqrt(((pos.x - x0) * (pos.x - x0) + (pos.y - y0) * (pos.y - y0)).toDouble())
        if (dist > radius) {
            pos.set(((pos.x - x0) * radius / dist + x0).toFloat(), ((pos.y - y0) * radius / dist + y0).toFloat())
        }
        invalidate()
        if (e.actionMasked == MotionEvent.ACTION_UP || e.actionMasked == MotionEvent.ACTION_CANCEL) {
            resetCtrlPos()
            return true
        }
        val p = power()
        val a = angle()
        listener?.onValueChanged(a, p, if (p > threshold) direction() else 0)
        return true
    }

    fun resetCtrlPos() {
        pos.set(cx.toFloat(), cy.toFloat())
        lastPower = 0; lastAngle = 0
        listener?.onValueChanged(0, 0, 0)
        invalidate()
    }
}
