package com.ayman.cloudcar.ui

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Rect
import android.graphics.RectF
import android.util.AttributeSet
import android.view.LayoutInflater
import android.view.MotionEvent
import android.view.View
import android.widget.EditText
import android.widget.ImageButton
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import com.ayman.cloudcar.R

/** Semi-transparent action button that lights up when pressed or selected. */
class ActionButtonView @JvmOverloads constructor(ctx: Context, attrs: AttributeSet? = null, def: Int = 0) :
    ImageButton(ctx, attrs, def) {
    init { imageAlpha = 130 }

    override fun onTouchEvent(event: MotionEvent): Boolean {
        if (isEnabled) when (event.actionMasked) {
            MotionEvent.ACTION_DOWN -> imageAlpha = 255
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> if (!isSelected) imageAlpha = 130
        }
        return super.onTouchEvent(event)
    }

    override fun setSelected(selected: Boolean) {
        imageAlpha = if (selected) 255 else 130
        super.setSelected(selected)
    }
}

/** Square title-bar button. */
class HeaderButtonView @JvmOverloads constructor(ctx: Context, attrs: AttributeSet? = null, def: Int = 0) :
    ImageButton(ctx, attrs, def) {

    override fun onTouchEvent(event: MotionEvent): Boolean {
        when (event.actionMasked) {
            MotionEvent.ACTION_DOWN -> imageAlpha = 125
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> imageAlpha = 255
        }
        return super.onTouchEvent(event)
    }

    override fun onMeasure(w: Int, h: Int) {
        val s = minOf(measureSpec(w), measureSpec(h))
        setMeasuredDimension(s, s)
    }

    private fun measureSpec(spec: Int) =
        if (MeasureSpec.getMode(spec) == MeasureSpec.UNSPECIFIED) 200 else MeasureSpec.getSize(spec)
}

class ButtonView @JvmOverloads constructor(ctx: Context, attrs: AttributeSet? = null, def: Int = 0) :
    ImageButton(ctx, attrs, def)

/** Red dot + elapsed time while recording. */
class RecordView @JvmOverloads constructor(ctx: Context, attrs: AttributeSet? = null, def: Int = 0) :
    TextView(ctx, attrs, def) {
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)

    override fun onDraw(canvas: Canvas) {
        p.style = Paint.Style.FILL
        p.color = Color.parseColor("#88ff3b30")
        p.typeface = typeface
        p.textSize = textSize
        val h = height
        canvas.drawCircle(h / 2f, h / 2f, h / 3f, p)
        val b = Rect()
        val t = text.toString()
        p.getTextBounds(t, 0, t.length, b)
        canvas.drawText(t, h + 10f, (-b.top + (h - b.height()) / 2).toFloat(), p)
    }
}

class BatteryView @JvmOverloads constructor(ctx: Context, attrs: AttributeSet? = null, def: Int = 0) :
    ImageView(ctx, attrs, def) {
    private var value = 100f
    private var charging = false
    private val label: Bitmap? = BitmapFactory.decodeResource(resources, R.drawable.ico_charging)
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)

    init { setBackgroundResource(R.drawable.bg_battery) }

    fun setAmount(v: Float) { value = v.coerceIn(0f, 100f); invalidate() }
    fun setCharging(c: Boolean) { charging = c; invalidate() }

    override fun onDraw(canvas: Canvas) {
        p.color = Color.parseColor(if (value > 20f) "#22c064" else "#ff0000")
        p.style = Paint.Style.FILL
        canvas.drawRoundRect(RectF(4f, 4f, width * 0.84f * value / 100f, height - 4f), 2f, 2f, p)
        if (charging && label != null) {
            canvas.drawBitmap(label, Rect(0, 0, label.width, label.height), Rect(0, 0, width, height), p)
        }
    }
}

/** Password field with an "eye" icon. */
class EditTextWithPicture(ctx: Context, attrs: AttributeSet?) : LinearLayout(ctx, attrs) {
    val text: EditText
    val imageView: ImageView

    init {
        orientation = HORIZONTAL
        LayoutInflater.from(ctx).inflate(R.layout.edit_text_with_picture, this, true)
        text = findViewById(R.id.comp_le_content)
        imageView = findViewById(R.id.imageView)
    }

    val content: String get() = text.text.toString()
}

/** The circular progress used during car configuration. */
class ProcessingCarView @JvmOverloads constructor(ctx: Context, attrs: AttributeSet? = null, def: Int = 0) :
    View(ctx, attrs, def) {
    private val car: Bitmap? = BitmapFactory.decodeResource(resources, R.drawable.config_car)
    private var value = 0
    private var color = Color.GRAY
    private var label: String? = null
    private var labelColor = Color.GRAY
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)

    fun setValue(v: Int) { value = v.coerceIn(0, 100) }
    fun setColor(c: Int) { color = c }
    fun setText(t: String?) { label = t }
    fun setTextColor(c: Int) { labelColor = c }

    override fun onMeasure(w: Int, h: Int) {
        fun m(s: Int) = if (MeasureSpec.getMode(s) == MeasureSpec.UNSPECIFIED) 200 else MeasureSpec.getSize(s)
        val s = minOf(m(w), m(h)); setMeasuredDimension(s, s)
    }

    override fun onDraw(canvas: Canvas) {
        val w = width
        val r = w / 2f
        val dens = resources.displayMetrics.density / 2f
        p.style = Paint.Style.FILL
        p.strokeWidth = 1f
        p.color = Color.WHITE; canvas.drawCircle(r, r, r, p)
        p.color = Color.parseColor("#f3f3f3"); canvas.drawCircle(r, r, r * 0.95f, p)
        p.color = color
        val l = r * 0.05f
        canvas.drawArc(RectF(l, l, w * 0.95f + l, w * 0.95f + l), -90f, value * 3.6f, true, p)
        p.color = Color.WHITE; canvas.drawCircle(r, r, r * 0.82f, p)
        p.style = Paint.Style.STROKE
        p.color = Color.parseColor("#eeeeee")
        canvas.drawCircle(r, r, r, p); canvas.drawCircle(r, r, r * 0.76f, p)
        car?.let {
            val cw = (w * 0.61f).toInt()
            val left = (w - cw) / 2
            val top = (left * 0.7f).toInt()
            canvas.drawBitmap(it, null, Rect(left, top, left + cw, top + cw), p)
        }
        p.style = Paint.Style.FILL
        val y = r * 1.5f
        val big = 80f * dens
        val small = 40f * dens
        val t = label
        if (t != null) {
            p.textSize = small; p.color = labelColor
            canvas.drawText(t, (w - p.measureText(t)) / 2f, y, p)
            return
        }
        p.color = Color.parseColor("#888888")
        val v = value.toString()
        p.textSize = big; val tw = p.measureText(v)
        p.textSize = small; val pw = p.measureText("%")
        val x = (w - tw - pw) / 2f
        p.textSize = big; canvas.drawText(v, x, y, p)
        p.textSize = small; canvas.drawText("%", x + tw + 5f, y, p)
    }
}
